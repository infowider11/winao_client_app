class LatLng {
  final double latitude;
  final double  longitude;

  LatLng({required this.latitude,required this.longitude});
}