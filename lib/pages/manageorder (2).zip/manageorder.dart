// import 'dart:developer';
// import 'dart:html';
// import 'dart:io';
//
import 'dart:developer';
import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_paypal/flutter_paypal.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:winao_client_app/constants/sized_box.dart';
import 'package:winao_client_app/pages/support.dart';
import 'package:winao_client_app/widgets/CustomTexts.dart';
import 'package:winao_client_app/widgets/newloader.dart';

import '../constants/colors.dart';
import 'package:intl/intl.dart';

import '../services/api_urls.dart';
import '../services/auth.dart';
import '../services/webservices.dart';
// import '../widgets/CustomTexts.dart';
import '../widgets/customtextfield.dart';
import '../widgets/image.dart';
import '../widgets/image_picker.dart';
import '../widgets/loader.dart';
import '../widgets/showSnackbar.dart';
import '../widgets/star.dart';
import 'home.dart';
import 'myorder.dart';

import 'package:flutter_rating_bar/flutter_rating_bar.dart';
class ManageOrdersPage extends StatefulWidget {
  final String orderid;
  // final String refid;
  final Map orderData;
  const ManageOrdersPage({Key? key,
    required this.orderData,
    required this.orderid,

  }) : super(key: key);

  @override
  State<ManageOrdersPage> createState() => _ManageOrdersPageState();
}

class _ManageOrdersPageState extends State<ManageOrdersPage> {

  String dropdownvalue = '24hours';
  String accounttype = 'Ahhoros';

  // List of items in our dropdown menu
  var items = [
    '24hours',
    '36hours',
    '48hours',
    '72hours',
    '96hours',
  ];
  var items1 = [
    'Ahhoros',
    'o corriente',
  ];


  TextEditingController demoController = TextEditingController();
  TextEditingController banknameController = TextEditingController();
  TextEditingController accountnoController = TextEditingController();
  TextEditingController accountholderController = TextEditingController();
  TextEditingController cedularucController = TextEditingController();
  TextEditingController account_typeController = TextEditingController();

  TextEditingController idController = TextEditingController();
  TextEditingController feedbackController = TextEditingController();
  TextEditingController extendtimeController = TextEditingController();
  bool load=true;

  @override
  String orderdate = '';
  String recomendate = '';
  String paymentmethod='';
  String paymentstatus='';

  String address = '';
  String selectedindex = '';
  Map Getorderdetails={};
  List<dynamic> adminbankdetails = [];
  String payerID = '';
  String paymentId = '';
  String? user_id;
  double ?_ratingValue;
  String image2='';
  // bool load=false;
  File? image1;
  List product=[];
  Map data={};
  Map userdetails={};
  bool?userLoggedIn;

  void initState() {
    // TODO: implement initState
    print('the dacfta is ${widget.orderData}');
    print('orderidddd.... ${widget.orderid}');
    super.initState();
    getuserdetail();
    getorderdetails();
    getbankdetails();
    iserlogin();
  }
  iserlogin()async{
     userLoggedIn = await isUserLoggedIn();
     print('userLoggedIn----------${userLoggedIn}');
  }
  getuserdetail()async{
    var user= await getUserDetails();
    userdetails=user;
    print('userdetails------${userdetails}');
    print('userdetails------${userdetails['image']}');
  }
  getorderdetails() async {
    setState(() {
      load=true;
    });
    var res = await Webservices.getMap('${ApiUrls.orderdetails}?order_id=${widget.orderid}');
    // data=res['data'];
    paymentmethod=res['payment_method'];
    paymentstatus=res['payment_status'];
    print('payment methode------${paymentmethod}');
    print('payment methode------${res}');

    setState(() {
      load=false;
    });
    // print()
    var dis=0;
    for (var i=0;i<res['products'].length;i++){
      dis = dis + (int.parse(res['products'][i]['product']['price']) - int.parse(res['products'][i]['product']['winao_price'])) * int.parse(res['products'][i]['quantity'].toString());
    print('object ${dis}');
    }
    res['discountt']=dis;

    Getorderdetails = res;
    print('Getorderdetails.....${Getorderdetails}');
    Getorderdetails['totall']=double.parse(Getorderdetails['grand_total'].toString())+double.parse(Getorderdetails['shipping_cost'].toString());
    Getorderdetails['grand_total_new'] = dis + double.parse(Getorderdetails['grand_total'].toString());
    print('Getorderdetails..........${Getorderdetails['totall']}');
    print('createdate..........${res['created']}');
    orderdate=res['created'];
    recomendate=res['recommendation']['created_at'];
    product=res['products'];

    print('products..${product}');
    print('orderdate    858..${orderdate}');


    address=res['address'];
    print('address..${address}');
setState((){});
  }
  getbankdetails() async {
    var res = await Webservices.getList('${ApiUrls.adminbankdetails}');
    adminbankdetails = res;
    print('adminbankdetails...................$adminbankdetails');
  }
  onSuccessPaypal(Map params) async {
    try {
      loadingShow(context);
    } catch (e) {}

    Map<String, dynamic> data = {
      'trasnId':params['data']['cart'],
      'order_id':Getorderdetails['id'],
    };
    log('Dataforcheckout...........${data}');
    var res = await Webservices.postData(
        apiUrl: ApiUrls.updatepayment,
        body: data,
        context: context,
        showSuccessMessage: true);
    log('checkoutapires...........${res}');
    // print('checkoutapires...........${res['status'].toString()}');
    if (res['status'].toString()=='1') {
      // loadingHide(context);
      Navigator.pushReplacement(
          context,
          MaterialPageRoute(
              builder: (context) => MyorderPage(
                 )));
      await showDialog(
        context: context,
        builder: (context) {
          return Dialog(
            shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(0)),
            elevation: 16,
            child: Container(
              padding: EdgeInsets.all(20),
              height: 250.0,
              width: 100.0,
              child: ListView(
                children: <Widget>[
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      GestureDetector(
                        onTap: () {
                          Navigator.pop(context);
                        },
                        child: Align(
                          alignment: Alignment.topRight,
                          child: Icon(
                            Icons.close,
                            color: Colors.black,
                          ),
                        ),
                      ),
                    ],
                  ),
                  Icon(
                    Icons.check_circle_outline,
                    color: Colors.green,
                    size: 50,
                  ),
                  SizedBox(height: 20),
                  Center(
                    child: Text(
                      'Thank You!',
                      style: TextStyle(
                          color: Colors.black,
                          fontSize: 20,
                          fontFamily: 'regular',
                          fontWeight: FontWeight.bold),
                    ),
                  ),
                  vSizedBox,
                  Center(
                    child: Text(
                      'Order Placed Successfully..!',
                      style: TextStyle(
                        color: Colors.black,
                        fontSize: 15,
                        fontFamily: 'regular',
                      ),
                    ),
                  ),
                  vSizedBox,
                  ElevatedButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    child: Text('Ok'),
                    style: ElevatedButton.styleFrom(
                      shape: StadiumBorder(),
                      primary: MyColors.primaryColor,
                    ),
                  )
                ],
              ),
            ),
          );
        },
      );
    }
    try{
      loadingHide(context);
    }catch(e){

    }
  }


  void _close(BuildContext ctx) {
    Navigator.of(ctx).pop();
  }

   Future _showImage_popup(BuildContext ctx,) async{
    await showCupertinoModalPopup(
        context: ctx,
        builder: (_) => StatefulBuilder(
          builder: (context, setState) {
            return CupertinoActionSheet(
              actions: [
                CupertinoActionSheetAction(
                    onPressed: () async {
                      print('press1 cermera function');
                      image1 = await pickImage(false);
                      log('imageurl-------${image1}');
                      setState((){});
                      log('image1----$image1');

                      // Map<String,dynamic> data ={
                      //   'user_id':await getCurrentUserId(),
                      //   'order_id':Getorderdetails['order_uniqueid'],
                      // };
                      // Map<String,dynamic>files = {
                      //   // 'cover_image':image,
                      // };
                      // print('image1----$data');
                      // print('image1----$files');
                      //
                      // if(image1!=null){
                      //   files["image"]=image1;
                      // }
                      // var jsonResponse = await Webservices.postDataWithImageFunction(body: data, files: files,context: context,apiUrl: ApiUrls
                      //     .uploadreciept,);
                      // print('object 123456'+jsonResponse.toString());
                      // if(jsonResponse['status'].toString()=='1'){
                      // }
                      setState(() {
                      });
                      _close(ctx);
                    },
                    child: const Text('Take Camera')),
                CupertinoActionSheetAction(
                    onPressed: () async {
                      // images = [];
                      print('ddd');
                      image1 = await pickImage(true);
                      setState((){});
                      print('image----$image1');
                      Map<String,dynamic> data ={
                        'user_id':await getCurrentUserId(),
                        'order_id':Getorderdetails['order_uniqueid'],
                      };
                      Map<String,dynamic>files = {
                        // 'cover_image':image,
                      };


                      if(image1!=null){
                        files["receipt_image"]=image1;

                      }
                      var jsonResponse = await Webservices.postDataWithImageFunction(body: data, files: files,context: context,apiUrl: ApiUrls
                          .edit_profile_image,);
                      if(jsonResponse['status'].toString()=='1'){
                        // Navigator.pop(context);
                        updateUserDetails(jsonResponse['data']);
                        // await autofill();
                      }
                      setState(() {

                      });
                      _close(ctx);
                    },
                    child: const Text('Gallery')),
              ],
              cancelButton: CupertinoActionSheetAction(
                onPressed: () => _close(ctx),
                child: const Text('Close'),
              ),
            );
          }
        ));
  }





  ongoingScreen({required BuildContext context, required Map bank}){
    return Container(
      // ongoingData.length==0
      margin: EdgeInsets.only(top: 80),
      padding: EdgeInsets.symmetric(horizontal:16),
      child: Column(
        children: [
          Column(
            children: [
              Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Text( 'Bank Name :',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15,color: Colors.blueGrey),),
                      Text('${bank['bank_name']}',style: TextStyle(fontWeight: FontWeight.w300,fontSize: 15,color: Colors.blueGrey),)
                    ],
                  ),
              vSizedBox,
              Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Text( 'Type of account :',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15,color: Colors.blueGrey),),
                      Text('${bank['type_of_account']}',style: TextStyle(fontWeight: FontWeight.w300,fontSize: 15,color: Colors.blueGrey),)
                    ],
                  ),
              vSizedBox,
              Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Text( 'Account Number :',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15,color: Colors.blueGrey),),
                      Text('${bank['account_no']}',style: TextStyle(fontWeight: FontWeight.w300,fontSize: 15,color: Colors.blueGrey),)
                    ],
                  ),
              vSizedBox,
              Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Text( 'Email : ',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15,color: Colors.blueGrey),),
                      Text('${bank['email']}',style: TextStyle(fontWeight: FontWeight.w300,fontSize: 15,color: Colors.blueGrey),)
                    ],
                  ),
              vSizedBox,
              Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Text( 'Account Holder :',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15,color: Colors.blueGrey),),
                      Text('${bank['account_holder']}',style: TextStyle(fontWeight: FontWeight.w300,fontSize: 15,color: Colors.blueGrey),)
                    ],
                  ),
              vSizedBox,
              Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Text( 'Ciudad : ',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15,color: Colors.blueGrey),),
                      Text('${bank['ciudad']}',style: TextStyle(fontWeight: FontWeight.w300,fontSize: 15,color: Colors.blueGrey),)
                    ],
                  ),
              vSizedBox,
              Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Text( 'RUC Number :',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15,color: Colors.blueGrey),),
                      Text('${bank['ruc_no']}',style: TextStyle(fontWeight: FontWeight.w300,fontSize: 15,color: Colors.blueGrey),)
                    ],
                  ),
            ],
          )
        ],
      ),
    );
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(''),
      ),
      body: load?CustomLoader():Container(
        padding: EdgeInsets.all(16),
        child: ListView(
          // crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Order #${Getorderdetails['order_uniqueid']}',
                style:
                TextStyle(color: Colors.black, fontSize:20,
                    fontFamily: 'regular',fontWeight: FontWeight.bold),),

            // if(orderdate!='')
            Text('Order Date : ${DateFormat.yMMMd().format(DateTime.parse(orderdate.toString()))}',
                style:
                TextStyle(color: Colors.black, fontSize:18,
                  fontFamily: 'regular',),),

            Text('Recommended Date : ${DateFormat.yMMMd().format(DateTime.parse(recomendate))}',
              style:
              TextStyle(color: Colors.black, fontSize:15,
                fontFamily: 'regular',),),
            vSizedBox2,

            Text('Item Ordered :',style: TextStyle(fontSize: 18, ),),
            vSizedBox,

            for(var i=0;i<product.length;i++)
            Container(
              padding: EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: MyColors.whiteColor,
                border: Border(
                  bottom: BorderSide(
                    color: MyColors.greyColor,
                    width: 1
                  )
                )
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(product[i]['product']['title'].toString(), style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),),
                      Text("\$"+(double.parse(product[i]['product']['price'].toString())*int.parse(product[i]['quantity'])).toString(), style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: MyColors.primaryColor),),
                    ],
                  ),
                  vSizedBox05,
                  Container(
                    padding: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(
                      color: MyColors.greyColor,
                      borderRadius: BorderRadius.circular(10)
                    ),
                    child: Text(paymentstatus=='1'?product[i]['product_status'].toString():'waiting for payment', style: TextStyle(fontSize: 14),),
                  ),
                  vSizedBox2,
                  Row(
                    children: [
                      RichText(
                        text: TextSpan(
                          text: 'Price: ',
                          style: TextStyle(fontSize: 12, color: MyColors.blackColor, fontWeight: FontWeight.bold),
                          children:  <TextSpan>[
                            TextSpan(text: '\$'+product[i]['product']['price'], style: TextStyle(fontWeight: FontWeight.w400)),
                          ],
                        ),
                      ),
                      hSizedBox2,
                      RichText(
                        text: TextSpan(
                          text: 'Qty: ',
                          style: TextStyle(fontSize: 12, color: MyColors.blackColor, fontWeight: FontWeight.bold),
                          children:  <TextSpan>[
                            TextSpan(text: product[i]['quantity'].toString(), style: TextStyle(fontWeight: FontWeight.w400)),
                          ],
                        ),
                      ),
                    ],
                  ),
                  vSizedBox05,

                  //---------ALL ACTIONS HERE-------------

                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      //-----pending
                      if((paymentstatus=='0')&&((Getorderdetails['payment_method']=='Bank')&&(product[i]['status'].toString()=='1')))
                        Row(
                        children: [
                          Text('Payment Status :'),
                          Text('Pending',style: TextStyle(color: MyColors.redColor),)
                        ],
                      ),

                     //------ I received the product
                      if(((paymentstatus=='1')&&(product[i]['ship_status'].toString()=='0'))&&(product[i]['status'].toString()=='1')&&(userLoggedIn==true))
                        GestureDetector(
                        onTap: ()async {
                          showDialog(context: context, builder: (context1){
                            return AlertDialog(
                              title: Text('Recived',),
                              content: Text('Are you sure?'),
                              actions: [
                                TextButton(
                                    onPressed: () async {
                                      Map<String,dynamic> data ={
                                        // 'user_id':await getCurrentUserId(),
                                        'item_id':product[i]['id'],
                                        // 'seller_id':product[i]['seller_id'],
                                        // 'product_id':product[i]['product_id'],
                                        // 'rating':_ratingValue,
                                        // 'message':feedbackController.text,
                                      };
                                      print('data----$data');
                                      var res = await Webservices.postData(body: data, context: context,apiUrl: ApiUrls
                                          .markasdeliveredforcustomer,);
                                      log('markasdeliveredforcustomer--------'+res.toString());
                                      if(res['status'].toString()=='1'){
                                        getorderdetails();
                                        showDialog(
                                          context: context,
                                          builder: (context) {
                                            return StatefulBuilder(
                                                builder: (context, setState) {
                                                  return Dialog(
                                                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(0)),
                                                    elevation: 16,
                                                    child: Container(
                                                      // padding: EdgeInsets.symmetric(horizontal:10),
                                                      height:220,
                                                      // width: 360.0,
                                                      child: Column(
                                                        children: [
                                                          vSizedBox,
                                                          vSizedBox,
                                                          Text('How was the product ?',style: TextStyle(fontSize:20,fontWeight: FontWeight.bold),),
                                                          vSizedBox,
                                                          RatingBar(
                                                              initialRating: 0,
                                                              direction: Axis.horizontal,
                                                              allowHalfRating: true,
                                                              itemCount: 5,
                                                              ratingWidget: RatingWidget(
                                                                  full: const Icon(Icons.star, color: Colors.orange),
                                                                  half: const Icon(
                                                                    Icons.star_half,
                                                                    color: Colors.orange,
                                                                  ),
                                                                  empty: const Icon(
                                                                    Icons.star_outline,
                                                                    color: Colors.orange,
                                                                  )),
                                                              onRatingUpdate: (value) {
                                                                setState(() {
                                                                  _ratingValue = value;
                                                                  print('-----${_ratingValue}');
                                                                });
                                                              }),
                                                          Padding(
                                                            padding: const EdgeInsets.symmetric(horizontal:20, vertical: 0),
                                                            child: TextField(
                                                              style: TextStyle(color:Color(0xff969BA0)),
                                                              controller:feedbackController,
                                                              decoration:  InputDecoration(
                                                                hintStyle: TextStyle(fontSize: 30.0, color:Color(0xff969BA0)),
                                                                enabledBorder: UnderlineInputBorder(
                                                                  borderSide: BorderSide(
                                                                      width:0.5,  color:Color(0xff969BA0)),
                                                                ),
                                                                labelText: 'Review (*)',
                                                                labelStyle: new TextStyle(color:Color(0xff969BA0)),
                                                              ),
                                                            ),
                                                          ),
                                                          vSizedBox,
                                                          Row(
                                                            mainAxisAlignment: MainAxisAlignment.end,
                                                            children: [
                                                              Container(
                                                                // padding: EdgeInsets.all(15),
                                                                child:RaisedButton(
                                                                  child: Text("Submit", style: TextStyle(fontSize: 15),),
                                                                  onPressed: () async{
                                                                    Map<String,dynamic> data ={
                                                                      'user_id':await getCurrentUserId(),
                                                                      'item_id':product[i]['id'].toString(),
                                                                      'seller_id':product[i]['seller_id'].toString(),
                                                                      'product_id':product[i]['product_id'].toString(),
                                                                      'rating':_ratingValue.toString(),
                                                                      'message':feedbackController.text,
                                                                    };
                                                                    print('data----$data');
                                                                    if(_ratingValue==''){
                                                                      showSnackbar(context, 'Please Enter your feedback.');
                                                                    }
                                                                    else if(feedbackController.text==''){
                                                                      showSnackbar(context, 'Please Enter your feedback.');
                                                                    }
                                                                    var res = await Webservices.postData(body: data, context: context,apiUrl: ApiUrls
                                                                        .submitrating,);
                                                                    log('markasdeliveredforcustomer--------'+res.toString());
                                                                    if(res['status'].toString()=='1'){
                                                                      getorderdetails();
                                                                      setState((){});
                                                                      Navigator.pop(context);
                                                                      showSnackbar(context, 'Thank you for rating.');
                                                                    }

                                                                  },
                                                                  color: MyColors.primaryColor,
                                                                  textColor:MyColors.whiteColor,
                                                                  padding: EdgeInsets.all(10),
                                                                  splashColor: Colors.grey,
                                                                ) ,
                                                              ),
                                                              hSizedBox,
                                                              Container(
                                                                // padding: EdgeInsets.all(15),
                                                                child:RaisedButton(
                                                                  child: Text("Close", style: TextStyle(fontSize: 15),),
                                                                  onPressed: () {
                                                                 Navigator.pop(context);
                                                                 },
                                                                  color: MyColors.primaryColor,
                                                                  textColor:MyColors.whiteColor,
                                                                  padding: EdgeInsets.all(10),
                                                                  splashColor: Colors.grey,
                                                                ) ,
                                                              ),
                                                            ],
                                                          ),
                                                          // Container(
                                                          //   // padding: EdgeInsets.all(15),
                                                          //   child:RaisedButton(
                                                          //     child: Text("Submit", style: TextStyle(fontSize: 15),),
                                                          //     onPressed: () async{
                                                          //       Map<String,dynamic> data ={
                                                          //         'user_id':await getCurrentUserId(),
                                                          //         'item_id':product[i]['id'].toString(),
                                                          //         'seller_id':product[i]['seller_id'].toString(),
                                                          //         'product_id':product[i]['product_id'].toString(),
                                                          //         'rating':_ratingValue.toString(),
                                                          //         'message':feedbackController.text,
                                                          //       };
                                                          //       print('data----$data');
                                                          //       if(_ratingValue==''){
                                                          //         showSnackbar(context, 'Please Enter your feedback.');
                                                          //       }
                                                          //       else if(feedbackController.text==''){
                                                          //         showSnackbar(context, 'Please Enter your feedback.');
                                                          //       }
                                                          //       var res = await Webservices.postData(body: data, context: context,apiUrl: ApiUrls
                                                          //           .submitrating,);
                                                          //       log('markasdeliveredforcustomer--------'+res.toString());
                                                          //       if(res['status'].toString()=='1'){
                                                          //         getorderdetails();
                                                          //         setState((){});
                                                          //         Navigator.pop(context);
                                                          //         showSnackbar(context, 'Thank you for rating.');
                                                          //       }
                                                          //
                                                          //     },
                                                          //     color: MyColors.primaryColor,
                                                          //     textColor:MyColors.whiteColor,
                                                          //     padding: EdgeInsets.all(10),
                                                          //     splashColor: Colors.grey,
                                                          //   ) ,
                                                          // ),
                                                          vSizedBox,
                                                        ],
                                                        // ],
                                                      ),
                                                    ),
                                                  );
                                                }
                                            );
                                          },
                                        );
                                      }

                                    }, child: Text('ok')),
                                TextButton(onPressed: () async {
                                  Navigator.pop(context1);
                                }, child: Text('cancel')
                                ),
                              ],
                            );
                          });

                        },
                        child: Container(
                          padding: EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                          decoration: BoxDecoration(
                              color: MyColors.whiteColor,
                              border: Border.all(
                                  color: MyColors.primaryColor,
                                  width:1
                              )
                          ),
                          child: Text('I received the product', style: TextStyle(color: MyColors.primaryColor),),
                        ),
                      ),
                      hSizedBox,
                      if(paymentstatus=='1'&&(product[i]['status'].toString()=='1')&&(product[i]['ship_status'].toString()=='0')&&(userLoggedIn==true))
                        GestureDetector(
                          onTap: (){
                            showDialog(context: context, builder: (context1){
                              return AlertDialog(
                                title: Text('Cancel',),
                                content: Text('Are you sure?'),
                                actions: [
                                  TextButton(
                                      onPressed: () async {
                                        var c = '${ApiUrls.cancelitem}?item_id=${product[i]['id']}&user_id=${await getCurrentUserId()}';
                                        print('this is url----'+c);
                                        var res = await Webservices.getMap(c);
                                        var canorderapi=res;
                                        print('cancelorder-----${res}');
                                        print('cancelorder-----${canorderapi}');
                                        // print('cancelorder-----${res['status']}');
                                        // print('cancelorder-----${res['message']}');
                                        // if(res['status'].toString()=='1'){
                                          getorderdetails();
                                        Navigator.pop(context1);
                                        setState((){});
                                        // }
                                        // else{
                                        //   showSnackbar(context, 'some this went wrong');
                                        // }
                                      }, child: Text('ok')),
                                  TextButton(onPressed: () async {
                                    Navigator.pop(context1);
                                  }, child: Text('cancel')
                                  ),
                                ],
                              );
                            });
                            },
                        child: Container(
                          padding: EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                          decoration: BoxDecoration(
                              color: MyColors.whiteColor,
                              border: Border.all(
                                  color: MyColors.primaryColor,
                                  width: 1
                              )
                          ),
                          child: Text('Cancel', style: TextStyle(color: MyColors.primaryColor),),
                        ),
                      ),
                      hSizedBox,
                      if((paymentstatus=='1')&&(product[i]['status'].toString()=='2'))
                        GestureDetector(
                          child: Container(
                            padding: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                            decoration: BoxDecoration(
                                color: MyColors.greenColor,
                                borderRadius: BorderRadius.circular(10)
                            ),
                            child: Text('Delivered', style: TextStyle(color: MyColors.whiteColor),),
                          ),
                        ),
                      hSizedBox,
                      if((paymentstatus=='1')&&(product[i]['status'].toString()=='2')&&(product[i]['reviews'].toString()!='0'))
                        GestureDetector(
                           onTap: (){
                             print('you press view reviews button');
                             showDialog(
                               context: context,
                               builder: (context) {
                                 return Dialog(
                                   shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5)),
                                   elevation: 16,
                                   child: Container(
                                     padding: EdgeInsets.all(10),
                                     height:250,
                                     child: Column(
                                       crossAxisAlignment: CrossAxisAlignment.start,
                                       children: [
                                         Row(
                                           mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                           children: [
                                             Text("Rating",style:
                                               TextStyle(
                                                 color: Colors.black,
                                                 fontSize: 25,
                                                 fontWeight: FontWeight.bold,
                                               )),
                                              IconButton(
                                               icon: new Icon(Icons.close,color: Colors.black,),
                                               onPressed: () { /* Your code */
                                                 Navigator.pop(context);
                                               },
                                             ),
                                           ],
                                         ),
                                         if(product[i]['reviews'].toString()!='0')
                                         Row(
                                           children: [
                                             Text('Rating :',style: TextStyle(fontSize:18,),),
                                             RatingBar(
                                                 initialRating: double.parse(product[i]['reviews']['rating']),
                                                 direction: Axis.horizontal,
                                                 allowHalfRating: true,
                                                 itemCount: 5,
                                                 ratingWidget: RatingWidget(
                                                     full: const Icon(Icons.star, color: Colors.orange),
                                                     half: const Icon(
                                                       Icons.star_half,
                                                       color: Colors.orange,
                                                     ),
                                                     empty: const Icon(
                                                       Icons.star_outline,
                                                       color: Colors.orange,
                                                     )),
                                                 onRatingUpdate: (value) {
                                                   setState(() {
                                                     _ratingValue = value;
                                                     print('-----${_ratingValue}');
                                                   });
                                                 }),

                                             if(product[i]['reviews'].toString()!='0')
                                             Text('${product[i]['reviews']['rating'].toString()}',style: TextStyle(fontSize:18),)
                                           ],
                                         ),

                                         if(product[i]['reviews'].toString()!='0')
                                           Text('Review',style: TextStyle(fontSize:20,fontWeight: FontWeight.w400,),),
                                         if(product[i]['reviews'].toString()!='0')
                                           Row(
                                           children: [
                                             Container(

                                               child: CircleAvatar(
                                                 backgroundImage: NetworkImage('${userdetails['image'].toString()}'),
                                                 backgroundColor: Colors.red.shade800,
                                                 radius:25,
                                               ),
                                               padding: EdgeInsets.all(10)
                                             ),
                                             Column(

                                               children: [
                                                 Text("${Getorderdetails['customer']['f_name'].toString()} :",style:
                                                 TextStyle(fontSize: 18,fontWeight: FontWeight.bold),),
                                                 ParagraphText(text:product[i]['reviews']['message'].toString(),),
                                               ],
                                               crossAxisAlignment: CrossAxisAlignment.start,
                                             ),

                                           ],
                                         ),
                                         if(product[i]['reviews'].toString()!='0')
                                         Row(
                                           mainAxisAlignment: MainAxisAlignment.end,
                                           children: [
                                             GestureDetector(

                                               child: Container(
                                                 padding: EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                                                 decoration: BoxDecoration(
                                                   borderRadius: BorderRadius.all(Radius.circular(15)),
                                                   color: MyColors.primaryColor,
                                                 ),
                                                 child: Text('Close', style: TextStyle(color: MyColors.whiteColor),),
                                               ),
                                               onTap: (){
                                                 Navigator.pop(context);
                                               },
                                             ),

                                           ],
                                         ),
                                       ],
                                       // ],
                                     ),
                                   ),
                                 );
                               },
                             );
                           },
                          child: Container(
                            padding: EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                            decoration: BoxDecoration(
                              color: MyColors.primaryColor,
                                borderRadius: BorderRadius.circular(10)
                            ),
                            child: Text('View Review', style: TextStyle(color: MyColors.whiteColor),),
                          ),
                        ),
                      hSizedBox,
                      if((paymentstatus=='1')&&(product[i]['status'].toString()=='2')&&(product[i]['reviews'].toString()=='0')&&(userLoggedIn==true))
                        GestureDetector(
                          onTap: (){
                            print('you press write reviews button');
                            showDialog(
                              context: context,
                              builder: (context) {
                                return Dialog(
                                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(0)),
                                  elevation: 16,
                                  child: Container(
                                    // padding: EdgeInsets.symmetric(horizontal:10),
                                    decoration: BoxDecoration(
                                        color: MyColors.whiteColor,
                                        borderRadius: BorderRadius.circular(10)
                                    ),
                                    height:250,
                                    // width: 360.0,
                                    child: Column(
                                      children: [
                                        vSizedBox,
                                        vSizedBox,
                                        Text('How was the product ?',style: TextStyle(fontSize:20,fontWeight: FontWeight.bold),),
                                        vSizedBox,
                                        Text('Rate it (1 to 5)',style: TextStyle(fontSize: 15,color: Colors.black),),
                                        vSizedBox,
                                        RatingBar(
                                            initialRating: 0,
                                            direction: Axis.horizontal,
                                            allowHalfRating: true,
                                            itemCount: 5,
                                            ratingWidget: RatingWidget(
                                                full: const Icon(Icons.star, color: Colors.orange),
                                                half: const Icon(
                                                  Icons.star_half,
                                                  color: Colors.orange,
                                                ),
                                                empty: const Icon(
                                                  Icons.star_outline,
                                                  color: Colors.orange,
                                                )),
                                            onRatingUpdate: (value) {
                                              setState(() {
                                                _ratingValue = value;
                                                print('-----${_ratingValue}');
                                              });
                                            }),
                                        Padding(
                                          padding: const EdgeInsets.symmetric(horizontal:20, vertical: 0),
                                          child: TextField(
                                            style: TextStyle(color:Color(0xff969BA0)),
                                            controller:feedbackController,
                                            decoration:  InputDecoration(
                                              hintStyle: TextStyle(fontSize: 30.0, color:Color(0xff969BA0)),
                                              enabledBorder: UnderlineInputBorder(
                                                borderSide: BorderSide(
                                                    width:0.5,  color:Color(0xff969BA0)),
                                              ),
                                              labelText: 'Review (*)',
                                              labelStyle: new TextStyle(color:Color(0xff969BA0)),
                                            ),
                                          ),
                                        ),
                                        vSizedBox,
                                        Row(
                                          mainAxisAlignment: MainAxisAlignment.end,

                                          children: [
                                            Container(
                                              // padding: EdgeInsets.all(15),
                                              padding: EdgeInsets.only(right:10),
                                              child:RaisedButton(
                                                child: Text("Close", style: TextStyle(fontSize: 15),),
                                                onPressed: () async{
                                                  Navigator.pop(context);
                                                  },
                                                color: MyColors.primaryColor,
                                                textColor:MyColors.whiteColor,
                                                padding: EdgeInsets.all(10),
                                                splashColor: Colors.grey,
                                              ) ,
                                            ),
                                            hSizedBox,
                                            Container(
                                              // padding: EdgeInsets.all(15),
                                              padding: EdgeInsets.only(right:10),
                                              child:RaisedButton(
                                                child: Text("Save as changes", style: TextStyle(fontSize: 15),),
                                                onPressed: () async{
                                                  Map<String,dynamic> data ={
                                                    'user_id':await getCurrentUserId(),
                                                    'item_id':product[i]['id'].toString(),
                                                    'seller_id':product[i]['seller_id'].toString(),
                                                    'product_id':product[i]['product_id'].toString(),
                                                    'rating':_ratingValue.toString(),
                                                    'message':feedbackController.text,
                                                  };
                                                  print('data----$data');
                                                  if(_ratingValue==''){
                                                    showSnackbar(context, 'Please Enter your feedback.');
                                                  }
                                                  if(feedbackController.text==''){
                                                    showSnackbar(context, 'Please Enter your feedback.');
                                                  }
                                                  var res = await Webservices.postData(body: data, context: context,apiUrl: ApiUrls
                                                      .submitrating,);
                                                  log('markasdeliveredforcustomer--------'+res.toString());
                                                  if(res['status'].toString()=='1'){
                                                    getorderdetails();
                                                    Navigator.pop(context);
                                                    setState((){});
                                                    showSnackbar(context, 'Thank you for rating.');
                                                  }

                                                },
                                                color: MyColors.primaryColor,
                                                textColor:MyColors.whiteColor,
                                                padding: EdgeInsets.all(10),
                                                splashColor: Colors.grey,
                                              ) ,
                                            ),
                                          ],
                                        ),

                                        vSizedBox,
                                      ],
                                      // ],
                                    ),
                                  ),
                                );
                              },
                            );
                          },
                          child: Container(
                            padding: EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                            decoration: BoxDecoration(
                              color: MyColors.primaryColor,
                                borderRadius: BorderRadius.circular(10)
                            ),
                            child: Text('Write Review', style: TextStyle(color: MyColors.whiteColor),),
                          ),
                        ),
                      hSizedBox,
                      if((paymentstatus=='1')&&(product[i]['status'].toString()=='3'))
                      GestureDetector(
                        child: Container(
                          padding: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                          decoration: BoxDecoration(
                              color: MyColors.redColor,
                              borderRadius: BorderRadius.circular(10)
                          ),
                          child: Text('Cancelled', style: TextStyle(color: MyColors.whiteColor),),
                        ),
                      ),
                      hSizedBox,

                      if(product[i]['refund_data'].toString()!='' && Getorderdetails['payment_method']=='Bank')
                      if((Getorderdetails['refund_status'].toString()=='0')&&(product[i]['refund_data']['bank_name'].toString()=='null')&&(product[i]['status'].toString()=='3')&&(Getorderdetails['payment_method']=='Bank'))
                      TextButton(
                        style: TextButton.styleFrom(
                          textStyle: const TextStyle(fontSize:15,decoration: TextDecoration.underline,),
                        ),
                        onPressed: () async{
                          await showDialog(
                            context: context,
                            builder: (context) {
                              return StatefulBuilder(
                                  builder: (context, setState) {
                                    return Dialog(
                                      shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(5)),
                                      elevation: 16,
                                      child: Container(
                                        padding: EdgeInsets.all(10),
                                        // height: MediaQuery.of(context).size.height,
                                        //   height: double.infinity,
                                        height:390,
                                        width: MediaQuery.of(context).size.width,
                                        child: ListView(
                                          children: <Widget>[
                                            Row(
                                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                              children: [
                                                Text('Bank Details', style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),),
                                                GestureDetector(
                                                  onTap: () {
                                                    Navigator.pop(context);
                                                  },
                                                  child: Align(
                                                    alignment: Alignment.topRight,
                                                    child: Icon(
                                                      Icons.close,
                                                      color: Colors.black,
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                            SizedBox(height: 20),
                                            CustomTextField(
                                              controller: banknameController,
                                              hintText: 'Bank Name',

                                            ),
                                            CustomTextField(
                                                controller: accountnoController,
                                                hintText: 'Account Number'),
                                            CustomTextField(
                                                controller: accountholderController,
                                                hintText: 'Account Holder'),
                                            CustomTextField(
                                                controller: cedularucController,
                                                hintText: 'Cedula OR Ruc'),
                                            Container(
                                              // padding:EdgeInsets.all(10),
                                              width: double.infinity,
                                              child: DecoratedBox(
                                                decoration: BoxDecoration(

                                                  // color:Colors.lightGreen, //background color of dropdown button
                                                  border: Border.all(color:MyColors.primaryColor, width:1), //border of dropdown button
                                                  borderRadius: BorderRadius.circular(30), //border raiuds of dropdown button
                                                ),
                                                child: Container(
                                                  padding:EdgeInsets.only(left: 10),
                                                  child: DropdownButton(
                                                    underline: Container(),
                                                    style: TextStyle(color:MyColors.grey, fontSize:15),
                                                    iconSize: 0.0,
                                                    dropdownColor:Colors.white,
                                                    value: accounttype,
                                                    // icon: const Icon(Icons.keyboard_arrow_down),
                                                    items: items1.map((String items1) {
                                                      return DropdownMenuItem(
                                                        value: items1,
                                                        child: Text(items1),
                                                      );
                                                    }).toList(),
                                                    onChanged: (String? newValue) {
                                                      setState(() {
                                                        accounttype = newValue!;
                                                        print('taphere-----${accounttype}');
                                                      });
                                                    },
                                                  ),
                                                ),
                                              ),
                                            ),
                                            Row(
                                              mainAxisAlignment: MainAxisAlignment.end,
                                              children: [
                                                ElevatedButton(
                                                  onPressed: () async {
                                                    if(banknameController.text==''){
                                                      showSnackbar(context, 'Please Enter your Bankname.');
                                                    }
                                                    else if(accountnoController.text==''){
                                                      showSnackbar(context, 'Please Enter your Account Number.');
                                                    }
                                                    else if(accountholderController.text==''){
                                                      showSnackbar(context, 'Please Enter your name.');
                                                    }
                                                    else if(cedularucController.text==''){
                                                      showSnackbar(context, 'Please Enter your Cedula OR Ruc.');
                                                    }
                                                    else if(accounttype.toString()==''){
                                                      showSnackbar(context, 'Please Select your Accounttype.');
                                                    }
                                                    else{
                                                      Map<String, dynamic> data = {
                                                        // "user_id": widget.ccustomer!['id'],
                                                        "bank_name": banknameController.text,
                                                        "account_no": accountnoController.text,
                                                        "account_holder":accountholderController.text,
                                                        "cedula_ruc": cedularucController.text,
                                                        "account_type": accounttype.toString(),
                                                        "order_id":product[i]['order_id'].toString(),
                                                        "product_id": product[i]['product']['id'].toString(),
                                                        // "order_id": widget.orderid.toString(),
                                                      };
                                                      log('Dataaddadderss...........${data}');
                                                      loadingShow(context);
                                                      var res = await Webservices.postData(
                                                          apiUrl: ApiUrls.add_bank_for_refund,
                                                          body: data,
                                                          context: context,
                                                          showSuccessMessage: true);
                                                      if (res['status'].toString() == '1') {
                                                        getorderdetails();
                                                        Navigator.pop(context);
                                                        setState((){});
                                                      }
                                                      print("Apiresponse.................");
                                                      loadingHide(context);
                                                      print("Apiresponse............" +
                                                          res.toString());
                                                    }
                                                  },
                                                  child: Text('Submit'),
                                                  style: ElevatedButton.styleFrom(
                                                    shape: StadiumBorder(),
                                                    primary: MyColors.primaryColor,
                                                  ),
                                                ),
                                                hSizedBox,
                                                ElevatedButton(
                                                  onPressed: () async {
                                                 Navigator.pop(context);
                                                  },
                                                  child: Text('close'),
                                                  style: ElevatedButton.styleFrom(
                                                    shape: StadiumBorder(),
                                                    primary: MyColors.redColor,
                                                  ),
                                                )
                                              ],
                                            ),
                                          ],
                                        ),
                                      ),
                                    );
                                  }
                              );
                            },
                          );
                          },
                        child: const Text('Provide Bank Details'),
                      ),
                      if(product[i]['refund_data'].toString()!='' && Getorderdetails['payment_method']=='Bank')
                        if((product[i]['refund_data']['refund_status'].toString()=='0')&&(product[i]['refund_data']['bank_name'].toString()!='null')&&(product[i]['status'].toString()=='3')&&(Getorderdetails['payment_method']=='Bank'))
                          Container(
                          padding: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                          decoration: BoxDecoration(
                              color: MyColors.greyColor,
                              borderRadius: BorderRadius.circular(10)
                          ),
                          child: Text('Your Refund Is Under process'),

                        ),
                      if(((product[i]['status'].toString()=='3'))&&(Getorderdetails['payment_method']=='Paypal'))
                      Container(
                        padding: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                        decoration: BoxDecoration(
                            color: MyColors.greyColor,
                            borderRadius: BorderRadius.circular(10)
                        ),
                        child: Text('Your Refund Is Completed'),

                      )
                    ],
                  ),
                  vSizedBox05,
                  if(product[i]['refund_data'].toString()!='' && Getorderdetails['payment_method']=='Bank')
                    if((product[i]['refund_data']['refund_status'].toString()=='2')&&(product[i]['status'].toString()=='3'))
                      Container(
                        padding: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                        decoration: BoxDecoration(
                            color: MyColors.greyColor,
                            borderRadius: BorderRadius.circular(10)
                        ),
                        child: Text('Your bank details is rejected please reupload bank details.'),

                      ),
                  if(product[i]['refund_data'].toString()!='' && Getorderdetails['payment_method']=='Bank')
                    if((product[i]['refund_data']['refund_status'].toString()=='2')&&(product[i]['status'].toString()=='3'))
                      Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          TextButton(onPressed:(){

                            showDialog(context: context, builder: (context1){
                              return AlertDialog(
                                title: Text('Reason',),
                                content: Text('${product[i]['refund_data']['reason'].toString()}'),
                                actions: [
                                  GestureDetector(

                                    child: Container(
                                      padding: EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.all(Radius.circular(15)),
                                        color: MyColors.primaryColor,
                                      ),
                                      child: Text('Close', style: TextStyle(color: MyColors.whiteColor),),
                                    ),
                                    onTap: (){
                                      Navigator.pop(context);
                                    },
                                  ),
                                ],
                              );
                            });

                          },
                            child: Text('View Reason',style: TextStyle(color: Colors.red,
                                decoration: TextDecoration.underline,
                                fontSize: 15),),
                          ),
                          GestureDetector(
                            onTap: ()async{
                              await showDialog(
                                  context: context,
                                  builder: (context) {
                                return StatefulBuilder(
                                    builder: (context, setState) {
                                      return Dialog(
                                        shape: RoundedRectangleBorder(
                                            borderRadius: BorderRadius.circular(5)),
                                        elevation: 16,
                                        child: Container(
                                          padding: EdgeInsets.all(10),
                                          // height: MediaQuery.of(context).size.height,
                                          //   height: double.infinity,
                                          height:390,
                                          width: MediaQuery.of(context).size.width,
                                          child: ListView(
                                            children: <Widget>[
                                              Row(
                                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                children: [
                                                  Text('Bank Details', style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),),
                                                  GestureDetector(
                                                    onTap: () {
                                                      Navigator.pop(context);
                                                    },
                                                    child: Align(
                                                      alignment: Alignment.topRight,
                                                      child: Icon(
                                                        Icons.close,
                                                        color: Colors.black,
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                              SizedBox(height: 20),
                                              CustomTextField(
                                                controller: banknameController,
                                                hintText: 'Bank Name',

                                              ),
                                              CustomTextField(
                                                  controller: accountnoController,
                                                  hintText: 'Account Number'),
                                              CustomTextField(
                                                  controller: accountholderController,
                                                  hintText: 'Account Holder'),
                                              CustomTextField(
                                                  controller: cedularucController,
                                                  hintText: 'Cedula OR Ruc'),
                                              Container(
                                                // padding:EdgeInsets.all(10),
                                                width: double.infinity,
                                                child: DecoratedBox(
                                                  decoration: BoxDecoration(

                                                    // color:Colors.lightGreen, //background color of dropdown button
                                                    border: Border.all(color:MyColors.primaryColor, width:1), //border of dropdown button
                                                    borderRadius: BorderRadius.circular(30), //border raiuds of dropdown button
                                                  ),
                                                  child: Container(
                                                    padding:EdgeInsets.only(left: 10),
                                                    child: DropdownButton(
                                                      underline: Container(),
                                                      style: TextStyle(color:MyColors.grey, fontSize:15),
                                                      iconSize: 0.0,
                                                      dropdownColor:Colors.white,
                                                      value: accounttype,
                                                      // icon: const Icon(Icons.keyboard_arrow_down),
                                                      items: items1.map((String items1) {
                                                        return DropdownMenuItem(
                                                          value: items1,
                                                          child: Text(items1),
                                                        );
                                                      }).toList(),
                                                      onChanged: (String? newValue) {
                                                        setState(() {
                                                          accounttype = newValue!;
                                                          print('taphere-----${accounttype}');
                                                        });
                                                      },
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Row(
                                                mainAxisAlignment: MainAxisAlignment.end,
                                                children: [
                                                  ElevatedButton(
                                                    onPressed: () async {
                                                      if(banknameController.text==''){
                                                        showSnackbar(context, 'Please Enter your Bankname.');
                                                      }
                                                      else if(accountnoController.text==''){
                                                        showSnackbar(context, 'Please Enter your Account Number.');
                                                      }
                                                      else if(accountholderController.text==''){
                                                        showSnackbar(context, 'Please Enter your name.');
                                                      }
                                                      else if(cedularucController.text==''){
                                                        showSnackbar(context, 'Please Enter your Cedula OR Ruc.');
                                                      }
                                                      else if(accounttype.toString()==''){
                                                        showSnackbar(context, 'Please Select your Accounttype.');
                                                      }
                                                      else{
                                                        Map<String, dynamic> data = {
                                                          // "user_id": widget.ccustomer!['id'],
                                                          "bank_name": banknameController.text,
                                                          "account_no": accountnoController.text,
                                                          "account_holder":accountholderController.text,
                                                          "cedula_ruc": cedularucController.text,
                                                          "account_type": accounttype.toString(),
                                                          "order_id":product[i]['order_id'].toString(),
                                                          "product_id": product[i]['product']['id'].toString(),
                                                          // "order_id": widget.orderid.toString(),
                                                        };
                                                        log('Dataaddadderss...........${data}');
                                                        loadingShow(context);
                                                        var res = await Webservices.postData(
                                                            apiUrl: ApiUrls.add_bank_for_refund,
                                                            body: data,
                                                            context: context,
                                                            showSuccessMessage: true);
                                                        if (res['status'].toString() == '1') {
                                                          getorderdetails();
                                                          Navigator.pop(context);
                                                          setState((){});
                                                        }
                                                        print("Apiresponse.................");
                                                        loadingHide(context);
                                                        print("Apiresponse............" +
                                                            res.toString());
                                                      }
                                                    },
                                                    child: Text('Submit'),
                                                    style: ElevatedButton.styleFrom(
                                                      shape: StadiumBorder(),
                                                      primary: MyColors.primaryColor,
                                                    ),
                                                  ),
                                                  hSizedBox,
                                                  ElevatedButton(
                                                    onPressed: () async {
                                                      Navigator.pop(context);
                                                    },
                                                    child: Text('close'),
                                                    style: ElevatedButton.styleFrom(
                                                      shape: StadiumBorder(),
                                                      primary: MyColors.redColor,
                                                    ),
                                                  )
                                                ],
                                              ),
                                            ],
                                          ),
                                        ),
                                      );
                                    }
                                );
                              },
                              );
                            },
                            child: Container(
                              padding: EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                              decoration: BoxDecoration(
                                  color: MyColors.primaryColor,
                                  borderRadius: BorderRadius.circular(10)
                              ),
                              child: Text('Reupload Bank Details', style: TextStyle(color: MyColors.whiteColor),),
                            ),
                          ),

                        ],
                      ),

                  if(product[i]['refund_data'].toString()!='' && Getorderdetails['payment_method']=='Bank')
                    if((product[i]['refund_data']['refund_status'].toString()=='1')&&(Getorderdetails['payment_method']=='Bank'))
                      Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          Container(
                            padding: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                            decoration: BoxDecoration(
                                color: MyColors.greyColor,
                                borderRadius: BorderRadius.circular(10)
                            ),
                            child: Text('Your Refund Is Completed'),
                          ),
                          hSizedBox,
                          InkWell(
                              child: new Text('View Proof',style: TextStyle(fontSize:15,decoration: TextDecoration.underline,color: Colors.blueAccent),),
                              onTap: () => launch(product[i]['refund_data']['refund_receipt'].toString())
                          ),
                        ],
                      ),


                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      if((paymentstatus=='1')&&(product[i]['status'].toString()=='1')&&(product[i]['ship_status'].toString()=='0')&&(userLoggedIn==true))
                        GestureDetector(
                          onTap: (){
                            showDialog(
                              context: context,
                              builder: (context) {
                                return StatefulBuilder(
                                  builder: (context, setState) {
                                    return Dialog(
                                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5)),
                                      elevation: 16,
                                      child: Container(
                                        padding: EdgeInsets.all(10),
                                        height:200,
                                        // width: 360.0,
                                        child: Column(
                                          mainAxisAlignment: MainAxisAlignment.start,
                                          children: [
                                            Row(
                                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                              children: [
                                                Text("Extend Waiting Time",style:
                                                  TextStyle(
                                                    color: Colors.black,
                                                    fontSize: 20,
                                                    fontWeight: FontWeight.bold
                                                  )),

                                                new IconButton(
                                                  icon: new Icon(Icons.close,color: Colors.black,),
                                                  onPressed: () { /* Your code */
                                                    Navigator.pop(context);
                                                  },
                                                ),
                                              ],
                                            ),
                                            Column(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Text('Extend time (hours)',
                                                  textAlign: TextAlign.left,
                                                  style: TextStyle(fontSize: 18),),
                                                // vSizedBox,
                                                Container(
                                                  padding:EdgeInsets.all(15),
                                                  width: double.infinity,
                                                  child: DecoratedBox(
                                                    decoration: BoxDecoration(

                                                        // color:Colors.lightGreen, //background color of dropdown button
                                                      border: Border.all(color: Colors.black38, width:0.5), //border of dropdown button
                                                      borderRadius: BorderRadius.circular(15), //border raiuds of dropdown button
                                                    ),
                                                    child: Container(
                                                      padding:EdgeInsets.only(left: 10),

                                                      child: DropdownButton(
                                                        underline: Container(),
                                                        iconSize: 0.0,
                                                        dropdownColor:Colors.white,
                                                        value: dropdownvalue,
                                                        // icon: const Icon(Icons.keyboard_arrow_down),
                                                        items: items.map((String items) {
                                                          return DropdownMenuItem(
                                                            value: items,
                                                            child: Text(items),
                                                          );
                                                        }).toList(),
                                                        onChanged: (String? newValue) {
                                                          setState(() {
                                                            dropdownvalue = newValue!;
                                                            print('taphere-----${dropdownvalue}');
                                                          });
                                                          },
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                // vSizedBox,
                                                Row(
                                                  mainAxisAlignment: MainAxisAlignment.end,
                                                  children: [
                                                    GestureDetector(

                                                      child: Container(
                                                        padding: EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                                                        decoration: BoxDecoration(
                                                          borderRadius: BorderRadius.all(Radius.circular(15)),
                                                          color: MyColors.primaryColor,
                                                        ),
                                                        child: Text('Close', style: TextStyle(color: MyColors.whiteColor),),
                                                      ),
                                                      onTap: (){
                                                        Navigator.pop(context);
                                                      },
                                                    ),
                                                    hSizedBox,
                                                    GestureDetector(
                                                      child: Container(
                                                        padding: EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                                                        decoration: BoxDecoration(
                                                          borderRadius: BorderRadius.all(Radius.circular(15)),
                                                          color: MyColors.primaryColor,
                                                        ),
                                                        child: Text('Save changes', style: TextStyle(color: MyColors.whiteColor),),
                                                      ),
                                                      onTap: () async{
                                                        // loadingShow(context);
                                                        Map<String, dynamic> data = {
                                                          // 'ext_time':extendtimeController.text,
                                                          'ext_time':dropdownvalue,
                                                          'item_id':product[i]['id'].toString(),
                                                        };
                                                        var res = await Webservices.postData(apiUrl: ApiUrls.extendtime,
                                                            body: data, context: context,showSuccessMessage:false);

                                                        print('apires-----${res}');
                                                        // if(res['sattus'].toString()==1){
                                                        Navigator.pop(context);
                                                          getorderdetails();
                                                          setState((){});
                                                        // }
                                                        // loadingHide(context);
                                                        }
                                                    ),
                                                  ],
                                                ),
                                              ],
                                            ),
                                          ],
                                          // ],
                                        ),
                                      ),
                                    );
                                  }
                                );
                              },
                            );
                          },
                          child: Container(
                            padding: EdgeInsets.symmetric(horizontal: 14, vertical: 10),

                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.all(Radius.circular(15)),
                              color: MyColors.primaryColor,
                            ),
                            child: Text('Extend Waiting Time (current:${product[i]['extend_time'].toString()})', style: TextStyle(color: MyColors.whiteColor),),
                          ),
                        ),
                      hSizedBox,
                    ],
                  ),
                  vSizedBox05,
                  // Image(
                  //   width: 10,
                  //     image: NetworkImage('${product[i]['refund_data']['refund_receipt']}'))
                ],
              ),
            ),
            vSizedBox2,


            Container(
              decoration: new BoxDecoration(
                  color:Color(0xffdee2e6).withOpacity(0.5),
                  borderRadius: BorderRadius.circular(0)
              ),
              // margin: EdgeInsets.all(20),
              padding: EdgeInsets.all(10),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('Subtotal',
                        style:
                        TextStyle(color: Colors.black, fontSize:15,
                            fontFamily: 'regular',fontWeight: FontWeight.bold),),
                      Text('\$'+Getorderdetails['grand_total_new'].toString(),
                        style:
                        TextStyle(color: Colors.black, fontSize:15,
                          fontFamily: 'regular',),),
                    ],
                  ),
                  vSizedBox2,
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('Discount(-)',
                        style:
                        TextStyle(color: Colors.black, fontSize:15,
                            fontFamily: 'regular',fontWeight: FontWeight.bold),),
                      Text('\$'+Getorderdetails['discountt'].toString(),
                        style:
                        TextStyle(color: Colors.black, fontSize:15,
                          fontFamily: 'regular',),),
                    ],
                  ),
                  vSizedBox2,
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('Shipping',
                        style:
                        TextStyle(color: Colors.black, fontSize:15,
                            fontFamily: 'regular',fontWeight: FontWeight.bold),),
                      Text('\$'+Getorderdetails['shipping_cost'],
                        style:
                        TextStyle(color: Colors.black, fontSize:15,
                          fontFamily: 'regular',),),
                    ],
                  ),
                  vSizedBox2,
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('Total',
                        style:
                        TextStyle(color: Colors.black, fontSize:15,
                            fontFamily: 'regular',fontWeight: FontWeight.bold),),
                      Text(
                        '\$${Getorderdetails['totall'].toString()}',
                        style:
                        TextStyle(color: Colors.black, fontSize:15,
                          fontFamily: 'regular',),),
                    ],
                  ),
                  vSizedBox2,
                ],
              ),
            ),
            vSizedBox,
            Text('Order Information',
              style:
              TextStyle(color: Colors.black, fontSize:18,
                fontFamily: 'regular',fontWeight: FontWeight.bold),),
            Text('${Getorderdetails['name']}',
              style:
              TextStyle(color: Colors.black, fontSize:15,
                fontFamily: 'regular',),),
            Text('${Getorderdetails['email']}',
              style:
              TextStyle(color: Colors.black, fontSize:15,
                fontFamily: 'regular',),),
            Text('${Getorderdetails['contact']}',
              style:
              TextStyle(color: Colors.black, fontSize:15,
                fontFamily: 'regular',),),
            Text('${Getorderdetails['city']}',
              style:
              TextStyle(color: Colors.black, fontSize:15,
                fontFamily: 'regular',),),
            Text('${Getorderdetails['zip']}',
              style:
              TextStyle(color: Colors.black, fontSize:15,
                fontFamily: 'regular',),),
            Text('${Getorderdetails['address']}',
              style:
              TextStyle(color: Colors.black, fontSize:15,
                fontFamily: 'regular',),),
            Text('${Getorderdetails['state']}',
              style:
              TextStyle(color: Colors.black, fontSize:15,
                fontFamily: 'regular',),),
            Text('${Getorderdetails['country']}',
              style:
              TextStyle(color: Colors.black, fontSize:15,
                fontFamily: 'regular',),),
            vSizedBox,
            Text('Payment Details',
              style:
              TextStyle(color: Colors.black, fontSize:18,
                fontFamily: 'regular',fontWeight: FontWeight.bold),),
            Text('Method:${Getorderdetails['payment_method']}',
              style:
              TextStyle(color: Colors.black, fontSize:15,
                fontFamily: 'regular',),),
            Text('Payment Status: ${(Getorderdetails['payment_status']=='0'&& Getorderdetails['receipt_status']=='1')?'Paid Waiting for Verification':
            (Getorderdetails['payment_status']=='0'&& Getorderdetails['receipt_status']=='0')?' Waiting for Payment':
            'Verified Payment Waiting for Shipping Or Local Pickup'}',
              style:
              TextStyle(
                  color: Colors.black, fontSize:15,
                fontFamily: 'regular',),),
            Text('Transaction Id : ${Getorderdetails['payment_id']}',
              style:
              TextStyle(color: Colors.black, fontSize:15,
                fontFamily: 'regular',),),

           // 3buttons------------
            if(((paymentmethod=='Bank')&&Getorderdetails['payment_status']!='1')&&((Getorderdetails['receipt_status']!='3') ))
              Row(
              children: [
                GestureDetector(
                  onTap: () {
                    },
                  child: Container(
                    // margin: EdgeInsets.all(25),
                    child: FlatButton(
                      child: Text('View Bank info', style: TextStyle(fontSize: 10.0),),
                      color: Colors.blueAccent,
                      textColor: Colors.white,
                      onPressed: () {
                        showDialog(
                          context: context,
                          builder: (context) {
                            return Dialog(
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(0)),
                              elevation: 16,
                              child: Container(
                                padding: EdgeInsets.symmetric(horizontal:10),
                                height:348,
                                // width: 360.0,
                                child: Column(
                                  children: [
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                Padding(
                                padding: const EdgeInsets.all(12.0),
                                child: Text("Bank Information",style:
                                TextStyle(
                                    color: Colors.black,
                                  fontSize: 20,

                                )),
                              ),
                                        new IconButton(
                                          icon: new Icon(Icons.close,color: Colors.black,),
                                          onPressed: () { /* Your code */
                                            Navigator.pop(context);
                                            },
                                        ),
                                      ],
                                    ),
                                    Container(
                                      height:300,
                                      width: 500,
                                      child: DefaultTabController(
                                        length: adminbankdetails.length,
                                        child: Builder(
                                          builder: (BuildContext context) => Stack(
                                            children: <Widget>[
                                              TabBarView(children: [
                                                for(var i=0;i<adminbankdetails.length;i++)
                                                ongoingScreen(context: context,bank:adminbankdetails[i]),
                                                // cancelledScreen(context: context),
                                                // purchasedScreen(context: context),
                                              ]),
                                              Container(
                                                margin: EdgeInsets.only(top:10),
                                                child: IconTheme(
                                                  data: IconThemeData(
                                                    size: 135.0,
                                                  ),
                                                  child: TabBar(
                                                    unselectedLabelColor: Color(0xFFF178B6),
                                                    labelColor: MyColors.whiteColor,
                                                    indicatorColor: MyColors.primaryColor,
                                                    indicator:  BoxDecoration(
                                                      borderRadius: BorderRadius.circular(10),
                                                      color: MyColors.primaryColor,
                                                    ),
                                                    // unselectedLabelStyle:,
                                                    tabs: [
                                                      for(var i=0;i<adminbankdetails.length;i++)
                                                      Tab(
                                                        child: Container(
                                                          height: 55,
                                                          width: 150,
                                                          decoration: BoxDecoration(
                                                              borderRadius: BorderRadius.circular(10),
                                                              border:Border.all(color: MyColors.primaryColor,)
                                                          ),
                                                          child: Column(
                                                            crossAxisAlignment: CrossAxisAlignment.center,
                                                            mainAxisAlignment: MainAxisAlignment.center,
                                                            children: [
                                                              Text(adminbankdetails[i]['bank_name'], textAlign: TextAlign.center,
                                                                style: TextStyle(
                                                                  fontSize: 11,
                                                                ),
                                                              ),
                                                            ],
                                                          ),

                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                  // ],
                                ),
                              ),
                            );
                          },
                        );
                        },
                    ),


                  ),
                ),
                Container(
                  // margin: EdgeInsets.all(25),
                  child: FlatButton(
                    child: Text('Change Payment method', style: TextStyle(fontSize: 10.0),),
                    color: Colors.orangeAccent,
                    textColor: Colors.white,
                    onPressed: () async{
                      print('prasoon------paypal click--------');
                      Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (BuildContext context) => UsePaypal(
                              sandboxMode: true,
                              clientId:
                              "AW1TdvpSGbIM5iP4HJNI5TyTmwpY9Gv9dYw8_8yW5lYIbCqf326vrkrp0ce9TAqjEGMHiV3OqJM_aRT0",
                              secretKey:
                              "EHHtTDjnmTZATYBPiGzZC_AZUfMpMAzj2VZUeqlFUrRJA_C0pQNCxDccB5qoRQSEdcOnnKQhycuOWdP9",
                              returnURL: "https://samplesite.com/return",
                              cancelURL: "https://samplesite.com/cancel",
                              transactions: [
                                {
                                  "amount": {
                                    "total":Getorderdetails['totall'].toString(),
                                    // "total": Grandtotal,
                                    "currency": "USD",
                                    "details": {
                                      "subtotal": Getorderdetails['totall'].toString(),
                                      "shipping": '0',
                                      "shipping_discount": '0'
                                    }
                                  },
                                  "description":
                                  "The payment transaction description.",
                                }
                              ],
                              note: "Contact us for any questions on your order.",
                              onSuccess: (Map params) async{
                                print('hello world');
                                print("onSuccess: $params");
                                print("payerID: ${params['payerID']}");
                                print("paymentId: ${params['paymentId']}");

                                payerID = params['payerID'];
                                paymentId = params['paymentId'];

                                onSuccessPaypal(params);
                                // log('Apiresponsecubmitcheckout...........${res}');
                                print('payment with paypal');
                              },
                              onError: (error) {
                                print("onError: $error");
                              },
                              onCancel: (params) {
                                print('cancelled handling----: $params');
                              }),
                        ),
                      );



                      },
                  ),


                ),
                // if(userLoggedIn==true&&(Getorderdetails['receipt_status'].toString()=='3'))
                Container(
                  // margin: EdgeInsets.all(25),
                  child: FlatButton(
                    child: Text('Upload Reciept', style: TextStyle(fontSize: 10.0),),
                    color: Colors.pinkAccent,
                    textColor: Colors.white,
                    onPressed: () {
                      showDialog(
                        context: context,
                        builder: (context) {
                          return StatefulBuilder(

                            builder: (context, setState) {
                              return Dialog(
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(0)),
                                elevation: 16,
                                child: Container(
                                  padding: EdgeInsets.symmetric(horizontal:10),
                                  height:240,
                                  // width: 360.0,
                                  child: (Getorderdetails['payment_status']=='0'&& Getorderdetails['receipt_status']=='1')?
                                  Column(
                                    children: [
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          Padding(
                                            padding: const EdgeInsets.all(12.0),
                                            child: Text("Upload Receipt",style:
                                            TextStyle(
                                              color: Colors.black,
                                              fontSize: 20,

                                            )),
                                          ),
                                          new IconButton(
                                            icon: new Icon(Icons.close,color: Colors.black,),
                                            onPressed: () { /* Your code */
                                              Navigator.pop(context);
                                            },
                                          ),
                                        ],
                                      ),

                                      Container(
                                        height: 150,
                                        child: Center(
                                          child: Text('Your Payment Verification is Under Process',
                                              style:TextStyle(
                                                color: Colors.black,
                                                fontSize:15,
                                              )
                                          ),
                                        ),
                                      )
                                    ],
                                  ):
                                  Column(
                                    children: [
                                      GestureDetector(
                                        onTap:  () async {
                                          await _showImage_popup(context);
                                          setState((){});
                                        },
                                        child: Center(
                                          child: Padding(
                                            padding: const EdgeInsets.only(top: 16.0),
                                            child: CustomCircularImage(
                                              imageUrl:'assets/images/add-file.png',
                                              image: image1,
                                              height: 70,
                                              fileType: image1==null?CustomFileType.asset:CustomFileType.file,
                                              width: 70,
                                            ),
                                          ),
                                        ),
                                      ),
                                      Padding(
                                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 16),
                                        child: TextFormField(
                                          controller:idController,
                                          decoration: const InputDecoration(

                                            border: UnderlineInputBorder(),
                                            labelText: 'Transaction / Payment ID',
                                          ),
                                        ),
                                      ),
                                      // new IconButton(
                                      //   icon: new Icon(Icons.close,color: Colors.black,),
                                      //   onPressed: () { /* Your code */
                                      //     Navigator.pop(context);
                                      //   },
                                      // ),
                                      Container(
                                        // padding: EdgeInsets.all(15),
                                        child:RaisedButton(

                                          child: Text("Submit", style: TextStyle(fontSize: 15),),
                                          onPressed: () async{
                                            Map<String,dynamic> data ={
                                              'user_id':await getCurrentUserId(),
                                              'order_id':Getorderdetails['id'],
                                              'payment_id':idController.text,
                                              // 'receipt_image':image1,
                                            };
                                            print('data----$data');

                                            // Map<String,dynamic>files = {
                                            //   'receipt_image':image1,
                                            //   // 'receipt_image':'ghrehrerehre',
                                            // };
                                            Map<String,dynamic>files = {
                                              // 'cover_image':image,

                                            };
                                            if(image1!=null){
                                              files["receipt_image"]=image1;
                                            }
                                            print('files----$files');
                                            log('the kjdsnhfsanbk ${files}');
                                            var res = await Webservices.postDataWithImageFunction(body: data, files: files,context: context,apiUrl: ApiUrls
                                                .uploadreciept,);
                                            log('jsonResponse--------'+res.toString());
                                            log('jsonResponse--------'+res['status'].toString());

                                            if(res['status'].toString()=='1'){
                                              log('getorderdetails---1');
                                              getorderdetails();
                                              log('getorderdetails---2');
                                              Navigator.pop(context);
                                              log('getorderdetails---3');
                                            }
                                            },
                                          color: MyColors.primaryColor,
                                          textColor:MyColors.whiteColor,
                                          padding: EdgeInsets.all(10),
                                          splashColor: Colors.grey,
                                        ) ,
                                      ),

                                    ],
                                    // ],
                                  ),
                                ),
                              );
                            }
                          );
                        },
                      );

                    },
                  ),


                ),
              ],
            ),
            Container(
              // padding: EdgeInsets.fromLTRB(10, 0, 10, 10),
              child: Row(
                children: [
                  Text('If you need any support and help please click here',
                    style: TextStyle( fontSize: 16, fontFamily: 'regular'),),
                ],
              ),
            ),
            Container(
              // padding: EdgeInsets.all(15),
              child:RaisedButton(

                child: Text("Support & Contact us", style: TextStyle(fontSize: 15),),
                onPressed: (){
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => const SupportPage()),
                  );


                },
                color: MyColors.primaryColor,
                textColor:MyColors.whiteColor,
                padding: EdgeInsets.all(10),
                splashColor: Colors.grey,
              ) ,
            ),

          ],

        ),
      ),

    );
  }
}



