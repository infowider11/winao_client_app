import 'package:flutter/material.dart';
import 'package:winao_client_app/constants/sized_box.dart';
import 'package:winao_client_app/pages/support.dart';
import 'package:winao_client_app/widgets/newloader.dart';

import '../constants/colors.dart';
import 'package:intl/intl.dart';

import '../services/api_urls.dart';
import '../services/webservices.dart';
import '../widgets/CustomTexts.dart';
class ManageOrdersPage extends StatefulWidget {
  final String orderid;
  // final String refid;
  final Map orderData;
  const ManageOrdersPage({Key? key,
    required this.orderData,
    required this.orderid,

  }) : super(key: key);

  @override
  State<ManageOrdersPage> createState() => _ManageOrdersPageState();
}

class _ManageOrdersPageState extends State<ManageOrdersPage> {
  bool load=true;

  @override
  String orderdate = '';
  String recomendate = '';
  String paymentmethod = '';
  String address = '';
  String selectedindex = '';
  Map Getorderdetails={};
  List<dynamic> adminbankdetails = [];

  List product=[];
  void initState() {
    // TODO: implement initState
    print('the dacfta is ${widget.orderData}');
    print('orderidddd.... ${widget.orderid}');
    super.initState();
    getorderdetails();
    getbankdetails();
  }

  getorderdetails() async {
    setState(() {
      load=true;
    });
    var res = await Webservices.getMap('${ApiUrls.orderdetails}?order_id=${widget.orderid}');
    paymentmethod=res['payment_method'];
    print('payment methode------${paymentmethod}');

    setState(() {
      load=false;
    });
    // print()
    var dis=0;
    for (var i=0;i<res['products'].length;i++){
      dis = dis + (int.parse(res['products'][i]['product']['price']) - int.parse(res['products'][i]['product']['winao_price'])) * int.parse(res['products'][i]['quantity'].toString());
    print('object ${dis}');
    }
    res['discountt']=dis;

    Getorderdetails = res;
    print('Getorderdetails.....${Getorderdetails}');
    Getorderdetails['totall']=double.parse(Getorderdetails['grand_total'].toString())+double.parse(Getorderdetails['shipping_cost'].toString());
    Getorderdetails['grand_total_new'] = dis + double.parse(Getorderdetails['grand_total'].toString());
    print('Getorderdetails..........${Getorderdetails['totall']}');
    print('createdate..........${res['created']}');
    orderdate=res['created'];
    recomendate=res['recommendation']['created_at'];
    product=res['products'];

    print('products..${product}');
    print('orderdate    858..${orderdate}');


    address=res['address'];
    print('address..${address}');
setState((){});
  }
  getbankdetails() async {
    var res = await Webservices.getList('${ApiUrls.adminbankdetails}');
    adminbankdetails = res;
    print('adminbankdetails...................$adminbankdetails');
  }

  ongoingScreen({required BuildContext context}){
    return Container(
      // ongoingData.length==0
      margin: EdgeInsets.only(top: 65),
      padding: EdgeInsets.symmetric(horizontal: 0),
      child:adminbankdetails
          .length==0?CustomLoader(): ListView.builder(
        itemCount: adminbankdetails.length,
        itemBuilder: (context, index){
          return GestureDetector(
            onTap: (){
              // Navigator.pushNamed(context, Detail_page.id);
            },
            child: Container(
              height: 10,
              width: 10,
              color: Colors.pink,
            ),
            // child: WinaoOngoingCard(ongoingData[index]),
            // child:  Horizontalcardongoing(ongoingData[index])
          );

        },
      ),
    );
  }
  cancelledScreen({required BuildContext context}){
    return Container(

      margin: EdgeInsets.only(top: 65),
      padding: EdgeInsets.symmetric(horizontal: 0),
      child:adminbankdetails.length==0?Center(child: ParagraphText(text: 'No Data Found',),): ListView.builder(
        itemCount: adminbankdetails.length,
        itemBuilder: (context, index){
          return GestureDetector(
            onTap: (){

              // Navigator.pushNamed(context, Detail_page.id);
            },
            child: Container(
              height: 10,
              width: 10,
              color: Colors.pink,
            ),
            // child: WinaoOngoingCard(cancelledData[index]),
            // child:  Horizontalcardcancel()
          );

        },
      ),
    );
  }
  purchasedScreen({required BuildContext context}){
    bool _hasBeenPressed = true;
    return Container(
      margin: EdgeInsets.only(top: 65),
      padding: EdgeInsets.symmetric(horizontal: 0),
      child: adminbankdetails.length==0?Center(child: ParagraphText(text: 'No Data Found',),): ListView.builder(
        itemCount: adminbankdetails.length,
        itemBuilder: (context, index){
          return GestureDetector(
            onTap: (){
              // Navigator.pushNamed(context, Detail_page.id);
            },
            child: Container(
              height: 10,
              width: 10,
              color: Colors.pink,
            ),
            // child: WinaoOngoingCard(purchasedData[index]),
            // child:  Horizontalcardcancel()
          );

        },
      ),
      // child: ListView(
      //   children: [
      //     GestureDetector(
      //         onTap: (){
      //           Navigator.pushNamed(context, Detail_page.id);
      //         },
      //         child: Card(
      //           clipBehavior: Clip.antiAlias,
      //           shape: RoundedRectangleBorder(
      //             borderRadius: BorderRadius.circular(10.0),
      //             side: BorderSide(color: Color(0xFF7A7A7A), width: 1),
      //           ),
      //           elevation: 0,
      //           child: Row(
      //             mainAxisAlignment: MainAxisAlignment.start,
      //             crossAxisAlignment: CrossAxisAlignment.start,
      //             children: [
      //
      //               Expanded(
      //                 flex: 2,
      //                 child: Column(
      //
      //                   children: [
      //                     Container(
      //                       // height: 98,
      //                       color: Color(0xFFF7F7F7),
      //                       padding: EdgeInsets.all(10),
      //                       child: Image.asset('assets/images/product.png',
      //                         fit: BoxFit.fitWidth,
      //                         width: 105,
      //                         height: 98,
      //                       ),
      //                     ),
      //                   ],
      //                 ),
      //               ),
      //
      //               Expanded(
      //                 flex: 5,
      //                 child: Column(
      //                   children: [
      //                     ListTile(
      //                       visualDensity: VisualDensity(horizontal: 0, vertical: -4),
      //                       contentPadding: EdgeInsets.only(top: 0, left: 10, bottom: 0),
      //
      //                       title: Padding(
      //                         padding: EdgeInsets.all(0),
      //                         child: Row(
      //                           mainAxisAlignment: MainAxisAlignment.spaceBetween,
      //                           crossAxisAlignment: CrossAxisAlignment.center,
      //                           children: [
      //                             Text('Price: 300',  style: TextStyle(
      //                                 color: Colors.black, fontFamily: 'semibold', fontSize: 13
      //                             ),
      //                             ),
      //
      //
      //                           ],
      //                         ),
      //                       ),
      //
      //                       subtitle: Text(
      //                         'Macbook Pro M1',
      //                         style: TextStyle(color: Colors.black, fontFamily: 'semibold', fontSize: 15),
      //                       ),
      //                     ),
      //
      //
      //                     Padding(
      //                       padding: const EdgeInsets.only(left: 10, right: 16, bottom: 5, top: 0),
      //                       child: Text(
      //                         '96W USB‑C Power Adapter included as free upgrade with selection of M1 Pro with 10‑core CPU...',
      //                         style: TextStyle(color: Colors.black.withOpacity(0.6), fontSize: 9),
      //                         maxLines: 2,
      //                       ),
      //                     ),
      //                     Row(
      //                       // mainAxisAlignment: MainAxisAlignment.spaceBetween,
      //                       crossAxisAlignment: CrossAxisAlignment.center,
      //                       children: [
      //                         GestureDetector(
      //                           onTap: () {showDialog<void>(context: context, builder: (context) => dialograte);},
      //                           child: Container(
      //                             margin: EdgeInsets.only(left: 10, right: 4),
      //                             // width: MediaQuery.of(context).size.width,
      //                             padding: EdgeInsets.symmetric(horizontal: 8, vertical: 5),
      //                             decoration: BoxDecoration(
      //                               color: _hasBeenPressed ? Colors.transparent: MyColors.primaryColor,
      //                               borderRadius: BorderRadius.circular(5),
      //                               border:Border.all(color: MyColors.primaryColor),
      //                             ),
      //                             child: Text(
      //                               'Rate Now',
      //                               textAlign: TextAlign.center,
      //                               style: TextStyle(
      //                                   color:MyColors.primaryColor,
      //                                   fontSize: 10,
      //                                   fontFamily: 'semibold'
      //                               ),
      //                             ),
      //                           ),
      //
      //                         ),
      //
      //                         GestureDetector(
      //                           onTap: (){
      //                             showDialog<void>(context: context, builder: (context) => dialog);
      //                           },
      //                           child: Container(
      //                             margin: EdgeInsets.only(left: 4, right: 4),
      //                             // width: MediaQuery.of(context).size.width,
      //                             padding: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      //                             decoration: BoxDecoration(
      //                               color:MyColors.primaryColor,
      //                               // gradient: hasGradient?gradient ??
      //                               //     LinearGradient(
      //                               //       colors: <Color>[
      //                               //         Color(0xFF064964),
      //                               //         Color(0xFF73E4D9),
      //                               //       ],
      //                               //     ):null,
      //                               borderRadius: BorderRadius.circular(5),
      //                               border:Border.all(color: MyColors.primaryColor),
      //                             ),
      //                             child: Text(
      //                               'Cancel',
      //                               textAlign: TextAlign.center,
      //                               style: TextStyle(
      //                                   color:MyColors.whiteColor,
      //                                   fontSize: 8,
      //                                   fontFamily: 'semibold'
      //                               ),
      //                             ),
      //                           ),
      //                         ),
      //                       ],
      //                     ),
      //                     vSizedBox,
      //                   ],
      //                 ),
      //               ),
      //
      //             ],
      //           ),
      //         )
      //     ),
      //     GestureDetector(
      //         onTap: (){
      //           Navigator.pushNamed(context, Detail_page.id);
      //         },
      //         child: Card(
      //           clipBehavior: Clip.antiAlias,
      //           shape: RoundedRectangleBorder(
      //             borderRadius: BorderRadius.circular(10.0),
      //             side: BorderSide(color: Color(0xFF7A7A7A), width: 1),
      //           ),
      //           elevation: 0,
      //           child: Row(
      //             mainAxisAlignment: MainAxisAlignment.start,
      //             crossAxisAlignment: CrossAxisAlignment.start,
      //             children: [
      //
      //               Expanded(
      //                 flex: 2,
      //                 child: Column(
      //                   mainAxisAlignment: MainAxisAlignment.start,
      //                   crossAxisAlignment: CrossAxisAlignment.start,
      //                   children: [
      //                     Container(
      //                       height: 240,
      //                       color: Color(0xFFF7F7F7),
      //                       padding: EdgeInsets.all(10),
      //                       child: Image.asset('assets/images/product.png',
      //                         fit: BoxFit.fitWidth,
      //                         width: 105,
      //                         height: 98,
      //                       ),
      //                     ),
      //                   ],
      //                 ),
      //               ),
      //
      //               Expanded(
      //                 flex: 5,
      //                 child: Column(
      //                   crossAxisAlignment: CrossAxisAlignment.start,
      //                   children: [
      //                     ListTile(
      //                       visualDensity: VisualDensity(horizontal: 0, vertical: -4),
      //                       contentPadding: EdgeInsets.only(top: 0, left: 10, bottom: 0),
      //
      //                       title: Padding(
      //                         padding: EdgeInsets.all(0),
      //                         child: Row(
      //                           mainAxisAlignment: MainAxisAlignment.spaceBetween,
      //                           crossAxisAlignment: CrossAxisAlignment.center,
      //                           children: [
      //                             Text('Price: 300',  style: TextStyle(
      //                                 color: Colors.black, fontFamily: 'semibold', fontSize: 13
      //                             ),
      //                             ),
      //
      //
      //                           ],
      //                         ),
      //                       ),
      //
      //                       subtitle: Text(
      //                         'Macbook Pro M1',
      //                         style: TextStyle(color: Colors.black, fontFamily: 'semibold', fontSize: 15),
      //                       ),
      //                     ),
      //
      //
      //                     Padding(
      //                       padding: const EdgeInsets.only(left: 10, right: 16, bottom: 5, top: 0),
      //                       child: Text(
      //                         '96W USB‑C Power Adapter included as free upgrade with selection of M1 Pro with 10‑core CPU...',
      //                         style: TextStyle(color: Colors.black.withOpacity(0.6), fontSize: 9),
      //                         maxLines: 2,
      //                       ),
      //                     ),
      //                     Padding(
      //                       padding: const EdgeInsets.symmetric(vertical: 5, horizontal: 10),
      //                       child: Text('Rating and Review', style: TextStyle(fontSize: 12, fontFamily: 'semibold'),),
      //                     ),
      //                     Container(
      //                       margin: EdgeInsets.symmetric(horizontal: 10, vertical: 0),
      //                       padding: EdgeInsets.all(10),
      //                       decoration: BoxDecoration(
      //                         color: Color(0xFEF9F9F9),
      //                         borderRadius: BorderRadius.circular(8)
      //                       ),
      //                       child: Column(
      //                         crossAxisAlignment: CrossAxisAlignment.start,
      //                         children: [
      //                           Row(
      //                             children: [
      //                               Icon(Icons.star, size: 18, color: MyColors.primaryColor,),
      //                               Icon(Icons.star, size: 18, color: MyColors.primaryColor),
      //                               Icon(Icons.star, size: 18, color: MyColors.primaryColor),
      //                               Icon(Icons.star_border, size: 18, color: MyColors.primaryColor),
      //                               Icon(Icons.star_border, size: 18, color: MyColors.primaryColor),
      //                               hSizedBox,
      //                               Container(
      //                                 padding: EdgeInsets.symmetric(vertical: 5, horizontal: 8),
      //                                 decoration: BoxDecoration(
      //                                   color: MyColors.primaryColor,
      //                                   borderRadius: BorderRadius.circular(5)
      //                                 ),
      //                                 child: Text('3', style: TextStyle(fontFamily: 'semibold', color: Colors.white, fontSize: 12),),
      //                               )
      //                             ],
      //                           ),
      //                           Text("Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.",
      //                             style: TextStyle(fontSize: 10, fontStyle: FontStyle.italic),
      //                           )
      //                         ],
      //                       ),
      //                     ),
      //                     vSizedBox,
      //                   ],
      //                 ),
      //               ),
      //
      //             ],
      //           ),
      //         )
      //     ),
      //
      //
      //   ],
      // ),
    );
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(''),
      ),
      body: load?CustomLoader():Container(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Order #${Getorderdetails['order_uniqueid']}',
                style:
                TextStyle(color: Colors.black, fontSize:20,
                    fontFamily: 'regular',fontWeight: FontWeight.bold),),

            // if(orderdate!='')
            Text('Order Date : ${DateFormat.yMMMd().format(DateTime.parse(orderdate.toString()))}',
                style:
                TextStyle(color: Colors.black, fontSize:18,
                  fontFamily: 'regular',),),

            Text('Recommended Date : ${DateFormat.yMMMd().format(DateTime.parse(recomendate))}',
              style:
              TextStyle(color: Colors.black, fontSize:15,
                fontFamily: 'regular',),),
            vSizedBox2,

            Text('Item Ordered :',style: TextStyle(fontSize: 18, ),),
            vSizedBox,

            Container(
              decoration: new BoxDecoration(
                  color:Color(0xffdee2e6).withOpacity(0.5),
                  borderRadius: BorderRadius.circular(0)
              ),
              // margin: EdgeInsets.all(20),
              padding: EdgeInsets.all(10),
              child: Table(
                defaultColumnWidth: FixedColumnWidth(60.0),
                children: [
                  // for(var i=0;i<widget.carts.length;i++)
                  TableRow(
                        decoration: new BoxDecoration(
                          // color: Color(0xffb4acac),
                            borderRadius: BorderRadius.circular(0)
                        ),
                        children: [
                          Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children:[
                                Text('Product Name',
                                  style: TextStyle(fontSize: 13, color:Colors.black,fontWeight: FontWeight.bold ),)]),
                          Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children:[
                                Text('Price(\$)',
                                  style: TextStyle(fontSize: 13, color:Colors.black,fontWeight: FontWeight.bold, ),)]),
                          Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children:[
                                Text('Quantity',
                                  style: TextStyle(fontSize: 13, color:Colors.black,fontWeight: FontWeight.bold ),)]),
                          Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children:[
                                Text('Total Price(\$)',
                                  style: TextStyle(fontSize: 13,color:Colors.black,fontWeight: FontWeight.bold ),)]),
                          Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children:[
                                Text('Status',
                                  style: TextStyle(fontSize: 13, color:Colors.black,fontWeight: FontWeight.bold ),)]),
                          // Column(
                          //     mainAxisAlignment: MainAxisAlignment.start,
                          //     crossAxisAlignment: CrossAxisAlignment.start,
                          //     children:[
                          //       Text('${widget.carts![i]['title'].toString()}',
                          //         style: TextStyle(fontSize: 13, color:Color(0xff969BA0), ),)]),
                          // Column(
                          //     children:[Text('\$${widget.carts![i]['winao_price'].toString()}'+' X '+'${widget.carts![i]['qty'].toString()}',
                          //       style: TextStyle(fontSize: 13, color: Color(0xff969BA0),),)]),
                          // Column(children:[Text('\$${widget.carts![i]['subtotal'].toString()}',
                          //   style: TextStyle(fontSize: 13, color: Color(0xff969BA0), ),)]),


                          vSizedBox4
                        ]),
                  for(var i=0;i<product.length;i++)

                    TableRow(
                      decoration: new BoxDecoration(
                        // color: Color(0xffb4acac),
                          borderRadius: BorderRadius.circular(0)
                      ),
                      children: [
                        Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children:[
                              Text(product[i]['product']['title'].toString(),
                                style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color:Color(0xff969BA0), ),)]),
                        Column(
                            children:[Text('\$'+product[i]['product']['price'],
                              style: TextStyle(fontSize: 15, color: Color(0xff969BA0),),)]),
                        Column(children:[Text(product[i]['quantity'],
                          style: TextStyle(fontSize: 13, color: Color(0xff969BA0), ),)]),
                        Column(children:[Text('\$'+(double.parse(product[i]['product']['price'].toString())*int.parse(product[i]['quantity'])).toString(),
                          style: TextStyle(fontSize: 13, color: Color(0xff969BA0), ),)]),
                        Column(children:[Text(product[i]['status'].toString()=='0'?'payment done':'waiting for payment',
                          style: TextStyle(fontSize: 13, color: Color(0xff969BA0), ),)]),
                        // Column(children:[Text('\$${shippingcost}',
                        //   style: TextStyle(fontSize: 13, color: Color(0xff969BA0), ),)]),
                        vSizedBox4



                      ]),




                ],
              ),
            ),
            vSizedBox2,
            Container(
              decoration: new BoxDecoration(
                  color:Color(0xffdee2e6).withOpacity(0.5),
                  borderRadius: BorderRadius.circular(0)
              ),
              // margin: EdgeInsets.all(20),
              padding: EdgeInsets.all(10),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('Subtotal',
                        style:
                        TextStyle(color: Colors.black, fontSize:15,
                            fontFamily: 'regular',fontWeight: FontWeight.bold),),
                      Text('\$'+Getorderdetails['grand_total_new'].toString(),
                        style:
                        TextStyle(color: Colors.black, fontSize:15,
                          fontFamily: 'regular',),),
                    ],
                  ),
                  vSizedBox2,
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('Discount(-)',
                        style:
                        TextStyle(color: Colors.black, fontSize:15,
                            fontFamily: 'regular',fontWeight: FontWeight.bold),),
                      Text('\$'+Getorderdetails['discountt'].toString(),
                        style:
                        TextStyle(color: Colors.black, fontSize:15,
                          fontFamily: 'regular',),),
                    ],
                  ),
                  vSizedBox2,
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('Shipping',
                        style:
                        TextStyle(color: Colors.black, fontSize:15,
                            fontFamily: 'regular',fontWeight: FontWeight.bold),),
                      Text('\$'+Getorderdetails['shipping_cost'],
                        style:
                        TextStyle(color: Colors.black, fontSize:15,
                          fontFamily: 'regular',),),
                    ],
                  ),
                  vSizedBox2,
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('Total',
                        style:
                        TextStyle(color: Colors.black, fontSize:15,
                            fontFamily: 'regular',fontWeight: FontWeight.bold),),
                      Text(
                        '\$${Getorderdetails['totall'].toString()}',
                        style:
                        TextStyle(color: Colors.black, fontSize:15,
                          fontFamily: 'regular',),),
                    ],
                  ),
                  vSizedBox2,
                ],
              ),
            ),
            vSizedBox,




            Text('Order Information',
              style:
              TextStyle(color: Colors.black, fontSize:18,
                fontFamily: 'regular',fontWeight: FontWeight.bold),),
            Text('${Getorderdetails['name']}',
              style:
              TextStyle(color: Colors.black, fontSize:15,
                fontFamily: 'regular',),),
            Text('${Getorderdetails['email']}',
              style:
              TextStyle(color: Colors.black, fontSize:15,
                fontFamily: 'regular',),),
            Text('${Getorderdetails['contact']}',
              style:
              TextStyle(color: Colors.black, fontSize:15,
                fontFamily: 'regular',),),
            Text('${Getorderdetails['city']}',
              style:
              TextStyle(color: Colors.black, fontSize:15,
                fontFamily: 'regular',),),
            Text('${Getorderdetails['zip']}',
              style:
              TextStyle(color: Colors.black, fontSize:15,
                fontFamily: 'regular',),),
            Text('${Getorderdetails['address']}',
              style:
              TextStyle(color: Colors.black, fontSize:15,
                fontFamily: 'regular',),),
            Text('${Getorderdetails['state']}',
              style:
              TextStyle(color: Colors.black, fontSize:15,
                fontFamily: 'regular',),),
            Text('${Getorderdetails['country']}',
              style:
              TextStyle(color: Colors.black, fontSize:15,
                fontFamily: 'regular',),),
            vSizedBox,
            Text('Payment Details',
              style:
              TextStyle(color: Colors.black, fontSize:18,
                fontFamily: 'regular',fontWeight: FontWeight.bold),),
            Text('Method:${Getorderdetails['payment_method']}',
              style:
              TextStyle(color: Colors.black, fontSize:15,
                fontFamily: 'regular',),),
            Text('Payment Status: ${Getorderdetails['payment_status']=='0'?'Waiting for payment':
            Getorderdetails['payment_status']=='1'?'Verified Payment Waiting for Shipping Or Local Pickup':
            'Cancelled'}',
              style:
              TextStyle(color: Colors.black, fontSize:15,
                fontFamily: 'regular',),),
            Text('Transaction Id : ${Getorderdetails['payment_id']}}',
              style:
              TextStyle(color: Colors.black, fontSize:15,
                fontFamily: 'regular',),),
           if(paymentmethod=='Bank')
            Row(
              children: [
                GestureDetector(
                  onTap: () {
                    },
                  child: Container(
                    // margin: EdgeInsets.all(25),
                    child: FlatButton(
                      child: Text('View Bank info', style: TextStyle(fontSize: 10.0),),
                      color: Colors.blueAccent,
                      textColor: Colors.white,
                      onPressed: () {
                        showDialog(
                          context: context,
                          builder: (context) {
                            return Dialog(
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(0)),
                              elevation: 16,
                              child: Container(
                                // height: 400.0,
                                // width: 360.0,
                                child: Column(
                                  children: [
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                Padding(
                                padding: const EdgeInsets.all(12.0),
                                child: Text("Bank Information",style:
                                TextStyle(
                                    color: Colors.black,
                                  fontSize: 20,

                                )),
                              ),
                                        // MainHeadingText(
                                        //   text: 'Bank Information',
                                        //   color: MyColors.blackColor,
                                        //   fontSize: 18,
                                        // ),
                                        new IconButton(
                                          icon: new Icon(Icons.close,color: Colors.black,),
                                          onPressed: () { /* Your code */
                                            Navigator.pop(context);
                                            },
                                        ),

                                      ],
                                    ),

                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                      children: [
                                        OutlinedButton(
                                          style: OutlinedButton.styleFrom(
                                            primary: Colors.blue,
                                            side:  BorderSide(color: Colors.blueAccent, width: 1),//<-- SEE HERE
                                          ),
                                          onPressed: (){
                                            print('selected index------${selectedindex}');
                                            for(var i=0;i<adminbankdetails.length;i++)
                                            adminbankdetails[i]['id']=selectedindex;
                                            print('selected index------${selectedindex}');
                                          },
                                          child: const Text(
                                            'Pichincha',
                                            style: TextStyle(fontSize:12),
                                          ),
                                        ),
                                        OutlinedButton(
                                          style: OutlinedButton.styleFrom(
                                            primary: Colors.blue,
                                            side:  BorderSide(color: Colors.blueAccent, width: 1),//<-- SEE HERE
                                          ),
                                          onPressed: (){
                                            print('selected index------${selectedindex}');
                                            for(var i=0;i<adminbankdetails.length;i++)
                                            adminbankdetails[i]['id']=selectedindex;
                                            print('selected index------${selectedindex}');

                                          },
                                          child: const Text(
                                            'Guayaquil',
                                            style: TextStyle(fontSize:12),
                                          ),
                                        ),
                                        OutlinedButton(
                                          style: OutlinedButton.styleFrom(
                                            primary: Colors.blue,
                                            side:  BorderSide(color: Colors.blueAccent, width: 1),//<-- SEE HERE
                                          ),
                                          onPressed: (){
                                            print('selected index------${selectedindex}');
                                            for(var i=0;i<adminbankdetails.length;i++)
                                            adminbankdetails[i]['id']=selectedindex;
                                            print('selected index------${selectedindex}');
                                            },
                                          child: const Text(
                                            'Pacifico',
                                            style: TextStyle(fontSize:12),
                                          ),
                                        )
                                      ],
                                    ),
                                    TabBarView(children: [
                                      ongoingScreen(context: context),
                                      cancelledScreen(context: context),
                                      purchasedScreen(context: context),
                                    ]),
                                    Container(
                                      margin: EdgeInsets.only(top:10),
                                      child: IconTheme(
                                        data: IconThemeData(
                                          size: 135.0,
                                        ),
                                        child: TabBar(
                                          unselectedLabelColor: Color(0xFFF178B6),
                                          labelColor: MyColors.whiteColor,
                                          indicatorColor: MyColors.primaryColor,
                                          indicator:  BoxDecoration(
                                            borderRadius: BorderRadius.circular(10),
                                            color: MyColors.primaryColor,

                                          ),
                                          // unselectedLabelStyle:,
                                          tabs: [
                                            Tab(
                                              child: Container(
                                                height: 55,
                                                width: 150,
                                                decoration: BoxDecoration(
                                                    borderRadius: BorderRadius.circular(10),
                                                    border:Border.all(color: MyColors.primaryColor,)
                                                ),
                                                child: Column(
                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                  mainAxisAlignment: MainAxisAlignment.center,
                                                  children: [
                                                    Text('Pichincha', textAlign: TextAlign.center,
                                                      style: TextStyle(
                                                        fontSize: 11,
                                                      ),
                                                    ),
                                                  ],
                                                ),

                                              ),
                                            ),
                                            Tab(
                                              // text: 'Cancelled',
                                              child: Container(
                                                width: 150,
                                                height: 55,
                                                decoration: BoxDecoration(
                                                    borderRadius: BorderRadius.circular(10),
                                                    border:Border.all(
                                                      color: MyColors.primaryColor,

                                                    )
                                                ),
                                                child:Column(
                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                  mainAxisAlignment: MainAxisAlignment.center,
                                                  children: [
                                                    Text('Guayaquil', textAlign: TextAlign.center,
                                                      style: TextStyle(
                                                        fontSize: 11,
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                            Tab(
                                              // text: 'Purchased',
                                              child: Container(
                                                width: 150,
                                                height: 55,
                                                decoration: BoxDecoration(
                                                    borderRadius: BorderRadius.circular(10),
                                                    border:Border.all(
                                                      color: MyColors.primaryColor,

                                                    )
                                                ),
                                                child: Column(
                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                  mainAxisAlignment: MainAxisAlignment.center,
                                                  children: [
                                                    Text('Pacifico', textAlign: TextAlign.center, style: TextStyle(fontSize: 11,),
                                                    ),
                                                  ],
                                                ),

                                              ),
                                            )
                                          ],
                                        ),
                                      ),
                                    ),
                                // Container(
                                //   padding: EdgeInsets.symmetric(horizontal: 10,vertical: 10),
                                //   child: Column(
                                //     children: [
                                //       for(var i=0;i<adminbankdetails.length;i++)
                                //         if('${adminbankdetails[i]['id']}'==selectedindex)
                                //           Column(
                                //             children: [
                                //               Row(
                                //                 mainAxisAlignment: MainAxisAlignment.start,
                                //                 children: [
                                //                   Text( 'Bank Name :',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15,color: Colors.blueGrey),),
                                //                   Text('${adminbankdetails[i]['bank_name']}',style: TextStyle(fontWeight: FontWeight.w300,fontSize: 15,color: Colors.blueGrey),)
                                //                 ],
                                //               ),
                                //               vSizedBox2,
                                //               // for(var i=0;i<adminbankdetails.length;i++)
                                //               Row(
                                //                 mainAxisAlignment: MainAxisAlignment.start,
                                //                 children: [
                                //                   Text( 'Type of account :',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15,color: Colors.blueGrey),),
                                //                   Text('${adminbankdetails[i]['type_of_account']}',style: TextStyle(fontWeight: FontWeight.w300,fontSize: 15,color: Colors.blueGrey),)
                                //                 ],
                                //               ),
                                //               vSizedBox2,
                                //               // for(var i=0;i<adminbankdetails.length;i++)
                                //               Row(
                                //                 mainAxisAlignment: MainAxisAlignment.start,
                                //                 children: [
                                //                   Text( 'Account Number :',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15,color: Colors.blueGrey),),
                                //                   Text('${adminbankdetails[i]['account_no']}',style: TextStyle(fontWeight: FontWeight.w300,fontSize: 15,color: Colors.blueGrey),)
                                //                 ],
                                //               ),
                                //               vSizedBox2,
                                //               // for(var i=0;i<adminbankdetails.length;i++)
                                //               Row(
                                //                 mainAxisAlignment: MainAxisAlignment.start,
                                //                 children: [
                                //                   Text( 'Email : ',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15,color: Colors.blueGrey),),
                                //                   Text('${adminbankdetails[i]['email']}',style: TextStyle(fontWeight: FontWeight.w300,fontSize: 15,color: Colors.blueGrey),)
                                //                 ],
                                //               ),
                                //               vSizedBox2,
                                //               // for(var i=0;i<adminbankdetails.length;i++)
                                //               Row(
                                //                 mainAxisAlignment: MainAxisAlignment.start,
                                //                 children: [
                                //                   Text( 'Account Holder :',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15,color: Colors.blueGrey),),
                                //                   Text('${adminbankdetails[i]['account_holder']}',style: TextStyle(fontWeight: FontWeight.w300,fontSize: 15,color: Colors.blueGrey),)
                                //                 ],
                                //               ),
                                //               vSizedBox2,
                                //               // for(var i=0;i<adminbankdetails.length;i++)
                                //               Row(
                                //                 mainAxisAlignment: MainAxisAlignment.start,
                                //                 children: [
                                //                   Text( 'Ciudad : ',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15,color: Colors.blueGrey),),
                                //                   Text('${adminbankdetails[i]['ciudad']}',style: TextStyle(fontWeight: FontWeight.w300,fontSize: 15,color: Colors.blueGrey),)
                                //                 ],
                                //               ),
                                //               vSizedBox2,
                                //               Row(
                                //                 mainAxisAlignment: MainAxisAlignment.start,
                                //                 children: [
                                //                   Text( 'RUC Number :',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15,color: Colors.blueGrey),),
                                //                   Text('${adminbankdetails[i]['ruc_no']}',style: TextStyle(fontWeight: FontWeight.w300,fontSize: 15,color: Colors.blueGrey),)
                                //                 ],
                                //               ),
                                //               vSizedBox2,
                                //               // for(var i=0;i<adminbankdetails.length;i++)
                                //               // Row(
                                //               //   mainAxisAlignment: MainAxisAlignment.start,
                                //               //   children: [
                                //               //     Text( 'BANK IMAGES',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 15,color: Colors.blueGrey),),
                                //               //     // NetworkImage("https://bluediamondresearch.com/WEB01/Winao/assets/uploads/20899560661652542196.png"),
                                //               //     // Image.network("https://bluediamondresearch.com/WEB01/Winao/assets/uploads/20899560661652542196.png"),
                                //               //     Image.network('${adminbankdetails[i]['image']}'),
                                //               //   ],
                                //               // ),
                                //               vSizedBox2
                                //             ],
                                //
                                //           )
                                //     ],
                                //   ),
                                // ),
                                  ],

                                  // mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                  // children: [
                                  //   for (var i = 0; i < adminbankdetails.length; i++)
                                  //   // if('${adminbankdetails[i]['id']}'=='3')
                                  //     Container(
                                  //       decoration: BoxDecoration(
                                  //         // color: MyColors.primaryColor,
                                  //           border: adminbankdetails[i]['id'].toString() ==
                                  //               selectedIndex
                                  //               ? Border.all(
                                  //             // color: _isVisible?: MyColors.primaryColor:null,
                                  //             color: MyColors.primaryColor,
                                  //             width: 2,
                                  //           )
                                  //               : null),
                                  //       child: GestureDetector(
                                  //         onTap: () {
                                  //           print('hdh');
                                  //           selectedIndex = adminbankdetails[i]['id'];
                                  //           // payment = '' ;
                                  //           print("selectedIndex........" +
                                  //               selectedIndex.toString());
                                  //           // print("visible"+adminbankdetails.toString());
                                  //           // print("visible"+adminbankdetails[i]['visible'].toString());
                                  //           // if(adminbankdetails[i]['visible'].toString()=='false')
                                  //           // {
                                  //           //   adminbankdetails[i]['visible']=true;
                                  //           // }
                                  //           // else{
                                  //           //   adminbankdetails[i]['visible']=false;
                                  //           // }
                                  //           // print("visible1"+adminbankdetails[i]['visible'].toString());
                                  //           setState(() {});
                                  //         },
                                  //         child: Image.network('${adminbankdetails[i]['image']}',
                                  //             width: 70, height: 40, fit: BoxFit.fill),
                                  //       ),
                                  //     ),
                                  // ],
                                ),
                              ),
                            );
                          },
                        );

                      },
                    ),


                  ),
                ),
                Container(
                  // margin: EdgeInsets.all(25),
                  child: FlatButton(
                    child: Text('Change Payment method', style: TextStyle(fontSize: 10.0),),
                    color: Colors.orangeAccent,
                    textColor: Colors.white,
                    onPressed: () {},
                  ),


                ),
                Container(
                  // margin: EdgeInsets.all(25),
                  child: FlatButton(
                    child: Text('Upload Reciept', style: TextStyle(fontSize: 10.0),),
                    color: Colors.pinkAccent,
                    textColor: Colors.white,
                    onPressed: () {},
                  ),


                )
              ],
            ),
            Container(
              // padding: EdgeInsets.fromLTRB(10, 0, 10, 10),
              child: Row(
                children: [
                  Text('If you need any support and help please click here',
                    style: TextStyle( fontSize: 16, fontFamily: 'regular'),),
                ],
              ),
            ),
            Container(
              // padding: EdgeInsets.all(15),
              child:RaisedButton(

                child: Text("Support & Contact us", style: TextStyle(fontSize: 15),),
                onPressed: (){
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => const SupportPage()),
                  );


                },
                color: MyColors.primaryColor,
                textColor:MyColors.whiteColor,
                padding: EdgeInsets.all(10),
                splashColor: Colors.grey,
              ) ,
            ),

          ],

        ),
      ),

    );
  }
}
